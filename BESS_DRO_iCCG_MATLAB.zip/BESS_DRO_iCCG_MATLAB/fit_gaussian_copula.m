function fit = fit_gaussian_copula(X)
% Gaussian copula fit from paired observations using Kendall's tau.
% Marginal distributions are handled separately by empirical ranks.

if size(X,2)~=2
    error('X must be N-by-2 paired forecast-error observations.');
end
X = X(all(isfinite(X),2),:);
N = size(X,1);
if N<20, error('At least 20 paired observations are required.'); end

tau = kendall_tau_manual(X(:,1),X(:,2));
rho = sin(pi/2*tau);
rho = min(0.999,max(-0.999,rho));

u1 = empirical_rank_uniform(X(:,1));
u2 = empirical_rank_uniform(X(:,2));
z1 = sqrt(2)*erfinv(2*u1-1);
z2 = sqrt(2)*erfinv(2*u2-1);
den = max(1-rho^2,1e-10);
logc = -0.5*log(den) - ...
    (rho^2*(z1.^2+z2.^2)-2*rho*z1.*z2)/(2*den);
logLik = sum(logc);
k = 1;

fit.N = N;
fit.tauEmp = tau;
fit.rho = rho;
fit.tauGaussian = 2/pi*asin(rho);
fit.logLikelihood = logLik;
fit.AIC = -2*logLik+2*k;
fit.BIC = -2*logLik+k*log(N);
fit.u = [u1 u2];
fit.z = [z1 z2];
end

function u = empirical_rank_uniform(x)
[~,ord]=sort(x);
r=zeros(size(x));
r(ord)=1:numel(x);
u=(r-0.5)/numel(x);
u=min(1-1e-10,max(1e-10,u));
end

function tau = kendall_tau_manual(x,y)
n=numel(x);
S=0;
for i=1:n-1
    dx=x(i)-x(i+1:end);
    dy=y(i)-y(i+1:end);
    S=S+sum(sign(dx.*dy));
end
tau=S/(n*(n-1)/2);
end
