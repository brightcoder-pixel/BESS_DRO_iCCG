function [C,nv] = add_network_soc(C,cfg,net,loadMW,loadMvar,pvAvail,pvCurt,pDG,pCh,pDis,pImp,pExp)
% Branch-flow SOCP constraints for the radial feeder.
% Power variables are per unit; DER/load inputs are MW/Mvar.

T=size(loadMW,2);
ne=net.ne; nb=net.nb;
P=sdpvar(ne,T,'full');
Q=sdpvar(ne,T,'full');
ell=sdpvar(ne,T,'full');
v=sdpvar(nb,T,'full');

C=[C, v>=cfg.vMin^2, v<=cfg.vMax^2, ell>=0, ell<=cfg.lMax];

for t=1:T
    C=[C,v(1,t)==1];
    for e=1:ne
        i=net.from(e); j=net.to(e);
        C=[C, v(j,t)==v(i,t)-2*(net.r(e)*P(e,t)+net.x(e)*Q(e,t))...
            +(net.r(e)^2+net.x(e)^2)*ell(e,t)];
        C=[C, cone([2*P(e,t);2*Q(e,t);ell(e,t)-v(i,t)],ell(e,t)+v(i,t))];
    end

    for b=2:nb
        ein=find(net.to==b);
        eout=find(net.from==b);
        pvAt=0; curtAt=0; dgAt=0;
        kpv=find(cfg.pvBuses==b,1);
        if ~isempty(kpv)
            pvAt=pvAvail(kpv,t);
            curtAt=pvCurt(kpv,t);
        end
        kdg=find(cfg.dgBuses==b,1);
        if ~isempty(kdg), dgAt=pDG(kdg,t); end
        pchAt=0; pdisAt=0;
        if b==cfg.bessBus
            pchAt=pCh(t); pdisAt=pDis(t);
        end
        pNet=loadMW(b,t)-pvAt+curtAt-dgAt+pchAt-pdisAt;
        qNet=loadMvar(b,t);
        lossP=sum(net.r(ein).*ell(ein,t));
        lossQ=sum(net.x(ein).*ell(ein,t));
        C=[C, sum(P(ein,t))-sum(P(eout,t))==pNet/cfg.baseMVA+lossP];
        C=[C, sum(Q(ein,t))-sum(Q(eout,t))==qNet/cfg.baseMVA+lossQ];
    end
    rootOut=find(net.from==1);
    C=[C, pImp(t)-pExp(t)==cfg.baseMVA*sum(P(rootOut,t))];
end

nv.P=P; nv.Q=Q; nv.ell=ell; nv.v=v;
end
