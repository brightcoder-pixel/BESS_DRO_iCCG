function Eref = interpolate_da_energy(EDA)
% Interpolate 25 hourly boundary energy states to 97 quarter-hour boundaries.
% EDA may contain numeric values or YALMIP symbolic expressions.
Eref=[];
for k=0:96
    if k==96
        ek=EDA(25);
    else
        h=floor(k/4)+1;
        r=mod(k,4)/4;
        ek=(1-r)*EDA(h)+r*EDA(h+1);
    end
    Eref=[Eref;ek]; %#ok<AGROW>
end
end
