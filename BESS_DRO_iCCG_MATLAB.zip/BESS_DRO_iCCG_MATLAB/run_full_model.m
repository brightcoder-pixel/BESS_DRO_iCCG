function results = run_full_model()
% RUN_FULL_MODEL
% Two-stage finite-support Wasserstein DRO scheduling prototype for a
% PV-rich IEEE-33 bus feeder. Requires MATLAB R2022a, YALMIP and CPLEX.
%
% IMPORTANT:
% The uploaded manuscript does not contain the raw forecast-error data,
% complete branch-flow input file, or solver model. Therefore this package
% includes a clearly identified synthetic-data demonstration and standard
% Baran-Wu IEEE-33 feeder data. Replace the synthetic assumptions before
% using numerical outputs as manuscript results.

clc; close all;
cfg = default_config();
rng(cfg.randomSeed,'twister');

if exist('sdpvar','file') ~= 2
    error('YALMIP is required. Install YALMIP and add it to the MATLAB path.');
end
if ~any(strcmpi(cfg.solver, {'cplex','gurobi','mosek'}))
    error('Unsupported solver setting. Use cplex, gurobi, or mosek.');
end

net = build_ieee33();
profiles = make_profiles(cfg,net);

fprintf('\n--- Synthetic paired forecast-error sample ---\n');
rawPairs = generate_synthetic_error_sample(cfg.NrawSynthetic,cfg.rhoTarget);
copula = fit_gaussian_copula(rawPairs);
fprintf('Empirical Kendall tau = %.4f; Gaussian rho = %.4f; implied tau = %.4f\n',...
    copula.tauEmp,copula.rho,copula.tauGaussian);

fprintf('\n--- Generate joint scenarios and reduce to representative trajectories ---\n');
rawScenarios = generate_joint_scenarios(cfg,net,profiles,copula,cfg.NscenarioRaw);
[representatives,clusterWeights,clusterInfo] = reduce_scenarios_kmeans(...
    cfg,net,profiles,rawScenarios,cfg.nRepresentative);
% The empirical center uses every raw daily trajectory. K-means centroids
% are used only to construct the reduced finite candidate support.
rawWeights=ones(numel(rawScenarios),1)/numel(rawScenarios);
[candidates,D] = make_candidate_pool(cfg,net,profiles,rawScenarios,representatives);
fprintf('Raw empirical trajectories: %d; K-means representatives: %d; candidate support: %d\n',...
    numel(rawScenarios),numel(representatives),numel(candidates));

% Initialize rainflow cycle templates from a seed trajectory. The cycle
% pairing is updated after each optimization round (sequential rainflow
% linearization).
seedE = cfg.E0 + 0.30*sin(linspace(0,4*pi,cfg.Nid+1))';
seedE = min(cfg.Emax,max(cfg.Emin,seedE));
seedCycles = rainflow_cycles(seedE);
cycleTemplates = repmat({seedCycles},numel(candidates),1);

fprintf('\n--- Outer rainflow / scheduling coordination ---\n');
for rIter = 1:cfg.maxRainflowOuter
    fprintf('Rainflow coordination iteration %d/%d\n',rIter,cfg.maxRainflowOuter);
    dro = solve_iccg_dro(cfg,net,profiles,candidates,rawWeights,D,cycleTemplates);
    updated = cell(numel(candidates),1);
    nChanged = 0;
    for j = 1:numel(candidates)
        if isempty(dro.recourse{j}) || ~isfield(dro.recourse{j},'E')
            updated{j} = cycleTemplates{j};
        else
            updated{j} = rainflow_cycles(dro.recourse{j}.E);
            if ~same_cycle_pattern(cycleTemplates{j},updated{j})
                nChanged = nChanged + 1;
            end
        end
    end
    fprintf('Updated rainflow pairings for %d/%d candidate trajectories.\n',...
        nChanged,numel(candidates));
    if nChanged == 0
        break;
    end
    cycleTemplates = updated;
end

results = struct();
results.config = cfg;
results.copula = copula;
results.clusterInfo = clusterInfo;
results.rawEmpiricalWeights = rawWeights;
results.clusterWeights = clusterWeights;
results.distanceMatrix = D;
results.candidates = candidates;
results.cycleTemplates = cycleTemplates;
results.DRO = dro;

fprintf('\n--- SOC relaxation diagnostics for candidate recourse solutions ---\n');
soc = soc_gap_metrics(dro.recourse);
results.SOC = soc;
disp(soc);

if cfg.runMonteCarlo
    fprintf('\n--- Out-of-sample Monte Carlo assessment (%d trajectories) ---\n',cfg.Nmc);
    mc = evaluate_monte_carlo(cfg,net,profiles,copula,dro.DA,dro.DAcost,...
        seedCycles);
    results.MonteCarlo = mc;
    disp(mc.summary);
end

if cfg.runBenchmarks
    fprintf('\n--- Optional finite-support benchmark models ---\n');
    results.Benchmarks = solve_benchmarks(cfg,net,profiles,candidates,...
        representatives,clusterWeights,cycleTemplates,D);
end

if ~exist(cfg.outputDir,'dir'), mkdir(cfg.outputDir); end
save(fullfile(cfg.outputDir,'BESS_DRO_iCCG_results.mat'),'results','-v7.3');
write_summary_files(cfg,results);
plot_model_results(results,cfg);
fprintf('\nCompleted. Results saved in: %s\n',cfg.outputDir);
end

function tf = same_cycle_pattern(a,b)
tf = numel(a)==numel(b);
if ~tf, return; end
if isempty(a), return; end
A = [[a.i1]' [a.i2]' [a.count]'];
B = [[b.i1]' [b.i2]' [b.count]'];
tf = isequal(size(A),size(B)) && max(abs(A(:)-B(:)))<1e-9;
end

function write_summary_files(cfg,R)
if ~exist(cfg.outputDir,'dir'), mkdir(cfg.outputDir); end
if isfield(R,'DRO')
    T = table(R.DRO.iteration(:),R.DRO.LBtrace(:),R.DRO.UBtrace(:),...
        R.DRO.gapTrace(:),R.DRO.activeCountTrace(:),...
        'VariableNames',{'Iteration','LowerBound','UpperBound','RelativeGap','ActiveScenarios'});
    writetable(T,fullfile(cfg.outputDir,'iCCG_convergence.csv'));
end
if isfield(R,'MonteCarlo')
    writetable(R.MonteCarlo.summary,fullfile(cfg.outputDir,'MonteCarlo_summary.csv'));
end
end
