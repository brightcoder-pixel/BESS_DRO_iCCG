function X = generate_synthetic_error_sample(N,rho)
% Synthetic standardized paired forecast-error sample.
% Replace this with paired normalized PV/load forecast-error observations.
z1 = randn(N,1);
z2 = rho*z1 + sqrt(max(0,1-rho^2))*randn(N,1);
X = [z1 z2];
end
