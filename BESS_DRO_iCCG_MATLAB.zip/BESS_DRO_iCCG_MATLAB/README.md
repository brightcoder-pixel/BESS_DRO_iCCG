# MATLAB project: Two-stage DRO / iCCG BESS scheduling

## 1. Purpose

This project is a MATLAB R2022a research implementation of a two-stage distributionally robust battery energy storage system scheduling method based on relevance perception. It includes:

- Gaussian-Copula PV/load uncertainty generation and fitting;
- K-means reduction to 20 representative daily trajectories;
- finite-support Wasserstein distributionally robust optimization;
- adaptive multi-cut column-and-constraint generation (iCCG);
- hourly day-ahead and 15-minute intraday recourse;
- branch-flow SOCP network constraints on a 33-bus radial feeder;
- rainflow cycle identification and cycle-depth piecewise-linear aging cost;
- backward-forward sweep AC power-flow verification;
- out-of-sample Monte Carlo voltage-violation probability and Wilson interval;
- SOC relaxation slack diagnostics;\n- rainflow/PWL cost consistency and EFC diagnostics;\n- convergence, energy-trajectory, and degradation-coefficient plots.

## 2. Required software



- MATLAB R2022a or newer;
- YALMIP;
- IBM ILOG CPLEX 12.10 (configured by default), or change `cfg.solver`
  to `gurobi` or `mosek`;
- Optimization Toolbox (`linprog`) for the finite-support transport LP.

The code uses `cone()` and `sdpvar()` from YALMIP.

## 3. Run

1. Add this project folder and all subfolders to the MATLAB path.
2. Confirm that YALMIP and the selected solver are installed and licensed.
3. Open `default_config.m`.
4. For a short software test, set `cfg.Nmc = 5`, `cfg.NscenarioRaw = 50`,
   `cfg.nRepresentative = 5`, and `cfg.maxICCG = 2`.
5. Run:

```matlab
results = run_full_model();
```

6. For the requested statistical assessment, restore `cfg.Nmc = 500`.
   The Monte Carlo evaluation is computationally expensive because every
   out-of-sample trajectory requires a 15-minute recourse SOCP solve.

## 4. Data provenance

- 12.66-kV feeder;
- total base demand 3.715 MW and 2.30 Mvar;
- PV buses 10, 17, 24, 30 and aggregate PV capacity 2.5 MW;
- BESS at bus 17, energy range 0.2-1.8 MWh, initial/terminal energy 1.0 MWh,
  charge/discharge limit 0.4 MW and efficiency 0.95;
- DGs at buses 6 and 25, each 0.5 MW;
- voltage limits 0.95-1.05 p.u.;
- DG cost 58 USD/MWh, curtailment penalty 75 USD/MWh,
  import/export limits 2/1 MW, export price 40 USD/MWh;
- 1-h day-ahead and 15-min intraday scheduling;
- degradation segment coefficients 2.2, 5.0, 9.8, 18.5 USD/MWh;
- 20 representative scenarios and Wasserstein radius 0.05.

## 5. Mathematical implementation notes

### 5.1 Finite-support Wasserstein DRO

The ambiguity set is implemented over a finite candidate support. Its
nominal center is the raw empirical distribution of all generated daily
trajectories with uniform weights. The 20 K-means representatives are used
only to construct a reduced candidate support, together with additional
adverse perturbations. Distances are calculated from every raw empirical
trajectory to each candidate support point.

The inner transport LP is:

max sum_{s,j} gamma(s,j) Q(x,xi_j)

subject to:

- sum_j gamma(s,j) = pi_s;
- sum_{s,j} gamma(s,j) d(s,j) <= epsilon_W;
- gamma(s,j) >= 0.

Its dual is represented by alpha_s and lambda:
alpha_s + lambda*d(s,j) >= Q(x,xi_j), lambda >= 0.

The iCCG procedure starts with one active candidate, solves the master,
evaluates all finite candidate recourse problems, and adds up to three most
violated candidate scenarios per iteration. 

### 5.2 Rainflow-coupled degradation

Rainflow turning-point pairings are fixed within each optimization solve.
The four PWL segment variables are linked to the energy difference between
the cycle's paired turning points. After solving, rainflow is applied again
and the cycle pairings are updated. This is a sequential rainflow/optimization
coordination heuristic. Its convergence and agreement with an independent
rainflow damage curve must be checked before making a physical validation
claim.

The coefficients 2.2, 5.0, 9.8, and 18.5 USD/MWh are carried over from the
manuscript but are reassigned to cycle-depth segments. 

### 5.3 SOC and AC validation

The scheduling model uses branch-flow SOC constraints. The code calculates
the conic slack v_i*l_ij - P_ij^2 - Q_ij^2. AC power flow is independently
checked using backward-forward sweep. SOC slack and AC voltage feasibility
are different diagnostics and should both be reported.

### 5.4 Monte Carlo confidence intervals

The voltage-violation probability is calculated over independent synthetic
out-of-sample trajectories. The 95% Wilson interval is reported. The cost
interval is a normal-approximation confidence interval for the sample mean.

## 6. Main output

The script writes:

- `BESS_DRO_iCCG_results.mat`;
- `iCCG_convergence.csv`;
- `MonteCarlo_summary.csv.
