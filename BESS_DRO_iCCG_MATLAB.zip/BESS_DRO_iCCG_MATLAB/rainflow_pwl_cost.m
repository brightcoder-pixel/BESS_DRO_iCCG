function [cost,detail] = rainflow_pwl_cost(E,cycles,cfg)
% Ex-post cycle-depth PWL cost, with cycle weights 1 or 0.5.
cost=0;
detail=zeros(numel(cycles),5);
for r=1:numel(cycles)
    range=abs(E(cycles(r).i2)-E(cycles(r).i1));
    rem=range;
    c=0;
    seg=zeros(1,4);
    for m=1:4
        used=min(cfg.degBreaksMWh(m),max(0,rem));
        seg(m)=used;
        c=c+cfg.degMarginal(m)*used;
        rem=rem-used;
    end
    cost=cost+cycles(r).count*c;
    detail(r,:)=[range/cfg.Erated*100 cycles(r).count seg(1) seg(2) seg(3)+seg(4)];
end
end
