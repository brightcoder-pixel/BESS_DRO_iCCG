function [q,rec] = solve_recourse(cfg,net,DA,scen,cycles)
% Solve a single 15-min recourse SOCP for fixed day-ahead decisions.

C=[];
[C,cost,V]=build_recourse_block(C,cfg,net,DA,scen,cycles);
ops=solver_options(cfg);
diagnostics=optimize(C,cost,ops);
if diagnostics.problem~=0
    warning('Recourse solve failed: %s',diagnostics.info);
    q=inf; rec=[];
    return;
end

q=value(cost);
rec.pCh=value(V.pCh);
rec.pDis=value(V.pDis);
rec.E=value(V.E);
rec.pDG=value(V.pDG);
rec.pCurt=value(V.pCurt);
rec.pImp=value(V.pImp);
rec.pExp=value(V.pExp);
rec.Cenergy=value(V.Cenergy);
rec.Cdeg=value(V.Cdeg);
rec.Ctrack=value(V.Ctrack);
rec.status=diagnostics.info;

P=value(V.network.P); Q=value(V.network.Q);
ell=value(V.network.ell); v=value(V.network.v);
from=net.from;
slack=zeros(net.ne,cfg.Nid);
for e=1:net.ne
    slack(e,:)=v(from(e),:).*ell(e,:)-P(e,:).^2-Q(e,:).^2;
end
den=max(v(from,:).*ell,1e-8);
rec.socSlack=slack;
rec.socSlackNormalized=slack./den;
rec.minSOCVoltage=sqrt(max(0,min(v(:))));
rec.maxSOCVoltage=sqrt(max(v(:)));
end
