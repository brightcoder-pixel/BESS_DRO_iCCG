function ci = wilson_interval(k,n,alpha)
% Wilson score interval for a binomial proportion.
if nargin<3, alpha=0.05; end
if n<=0, ci=[nan nan]; return; end
z=1.95996398454005;
if alpha~=0.05
    % For non-95% levels, use an approximate normal quantile.
    z=sqrt(2)*erfinv(1-alpha);
end
p=k/n;
den=1+z^2/n;
center=(p+z^2/(2*n))/den;
half=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/den;
ci=[max(0,center-half),min(1,center+half)];
end
