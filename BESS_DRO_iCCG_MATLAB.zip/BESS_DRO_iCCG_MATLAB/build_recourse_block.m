function [C,cost,V] = build_recourse_block(C,cfg,net,DA,scen,cycles)
% Build one 15-min recourse SOCP with fixed day-ahead mode commitments.

T=cfg.Nid;
pCh=sdpvar(T,1);
pDis=sdpvar(T,1);
E=sdpvar(T+1,1);
pDG=sdpvar(numel(cfg.dgBuses),T,'full');
pCurt=sdpvar(numel(cfg.pvBuses),T,'full');
pImp=sdpvar(T,1);
pExp=sdpvar(T,1);
sTrack=sdpvar(T,1);

uCh96=kron(DA.uCh,ones(4,1));
uDis96=kron(DA.uDis,ones(4,1));
pDGRef=kron(DA.pDG,ones(1,4));
pCurtRef=kron(DA.pCurt,ones(1,4));
pImpRef=kron(DA.pImp,ones(4,1));
pExpRef=kron(DA.pExp,ones(4,1));
Eref=interpolate_da_energy(DA.E);

C=[C, E(1)==cfg.E0, E(end)==cfg.E0,...
    E>=cfg.Emin, E<=cfg.Emax,...
    pCh>=0,pDis>=0,...
    pCh<=cfg.PchMax*uCh96,...
    pDis<=cfg.PdisMax*uDis96,...
    uCh96+uDis96<=1,...
    pDG>=0,pDG<=repmat(cfg.dgMax,1,T),...
    pCurt>=0,pCurt<=scen.pvMW,...
    pImp>=0,pImp<=cfg.gridImportMax,...
    pExp>=0,pExp<=cfg.gridExportMax,...
    sTrack>=0];

for t=1:T
    C=[C,E(t+1)==E(t)+cfg.etaCh*pCh(t)*cfg.dtID...
        -pDis(t)*cfg.dtID/cfg.etaDis];
    C=[C,E(t+1)-Eref(t+1)<=cfg.trackAllowance+sTrack(t)];
    C=[C,Eref(t+1)-E(t+1)<=cfg.trackAllowance+sTrack(t)];
end

[C,nv]=add_network_soc(C,cfg,net,scen.loadMW,scen.loadMvar,...
    scen.pvMW,pCurt,pDG,pCh,pDis,pImp,pExp);

% Rainflow cycle-depth PWL cost. Cycle pairings are fixed from the
% preceding rainflow iteration and updated outside the optimization.
Cdeg=0;
if ~isempty(cycles)
    nc=numel(cycles);
    z=sdpvar(4,nc,'full');
    C=[C,z>=0];
    for m=1:4
        C=[C,z(m,:)<=cfg.degBreaksMWh(m)];
    end
    for r=1:nc
        i=cycles(r).i1; j=cycles(r).i2;
        C=[C,sum(z(:,r))>=E(i)-E(j),...
            sum(z(:,r))>=E(j)-E(i)];
        Cdeg=Cdeg+cycles(r).count*sum(cfg.degMarginal(:).*z(:,r));
    end
else
    z=[];
end

priceID=kron(cfg.importPrice,ones(4,1));
dgDelta=sum(pDG-pDGRef,1)';
curtDelta=sum(pCurt-pCurtRef,1)';
Cenergy=cfg.dtID*sum((pImp-pImpRef).*priceID ...
    -(pExp-pExpRef)*cfg.exportPrice ...
    +cfg.dgCost*dgDelta+cfg.curtCost*curtDelta);
Ctrack=cfg.trackPenalty*sum(sTrack);
cost=Cenergy+Cdeg+Ctrack;

V.pCh=pCh; V.pDis=pDis; V.E=E; V.pDG=pDG; V.pCurt=pCurt;
V.pImp=pImp; V.pExp=pExp; V.sTrack=sTrack; V.Cenergy=Cenergy;
V.Cdeg=Cdeg; V.Ctrack=Ctrack; V.network=nv; V.z=z;
end
