function MC = evaluate_monte_carlo(cfg,net,profiles,copula,DA,DAcost,seedCycles)
% Out-of-sample evaluation using recourse optimization + AC power flow.
% This can be computationally expensive because each trajectory requires
% one SOCP recourse solve.

testScen=generate_joint_scenarios(cfg,net,profiles,copula,cfg.Nmc);
costs=nan(cfg.Nmc,1);
viol=zeros(cfg.Nmc,1);
minV=nan(cfg.Nmc,1);
maxSOC=nan(cfg.Nmc,1);
meanSOC=nan(cfg.Nmc,1);
cycleCost=nan(cfg.Nmc,1);
rainflowCost=nan(cfg.Nmc,1);
degRelError=nan(cfg.Nmc,1);
efc=nan(cfg.Nmc,1);

for n=1:cfg.Nmc
    cyc=seedCycles;
    [q,rec]=solve_recourse(cfg,net,DA,testScen(n),cyc);
    if isempty(rec) || ~isfinite(q)
        viol(n)=1;
        continue;
    end
    newCycles=rainflow_cycles(rec.E);
    if ~same_pattern_local(cyc,newCycles)
        [q,rec]=solve_recourse(cfg,net,DA,testScen(n),newCycles);
    end
    if isempty(rec) || ~isfinite(q)
        viol(n)=1;
        continue;
    end

    vmin=inf; vmax=0; anyViolation=false;
    for t=1:cfg.Nid
        pNet=testScen(n).loadMW(:,t);
        qNet=testScen(n).loadMvar(:,t);
        for k=1:numel(cfg.pvBuses)
            b=cfg.pvBuses(k);
            pNet(b)=pNet(b)-testScen(n).pvMW(k,t)+rec.pCurt(k,t);
        end
        for k=1:numel(cfg.dgBuses)
            b=cfg.dgBuses(k);
            pNet(b)=pNet(b)-rec.pDG(k,t);
        end
        pNet(cfg.bessBus)=pNet(cfg.bessBus)+rec.pCh(t)-rec.pDis(t);
        [vm,ok]=ac_power_flow_bfs(net,pNet,qNet);
        if ~ok
            anyViolation=true;
        end
        vmin=min(vmin,min(vm));
        vmax=max(vmax,max(vm));
        if min(vm)<cfg.vMin-1e-6 || max(vm)>cfg.vMax+1e-6
            anyViolation=true;
        end
    end
    viol(n)=anyViolation;
    minV(n)=vmin;
    costs(n)=DAcost+q;
    maxSOC(n)=max(rec.socSlackNormalized(:));
    meanSOC(n)=mean(rec.socSlackNormalized(:));
    cycleCost(n)=rec.Cdeg;
    [rainflowCost(n),~]=rainflow_pwl_cost(rec.E,newCycles,cfg);
    degRelError(n)=abs(cycleCost(n)-rainflowCost(n))/max(rainflowCost(n),cfg.epsNum);
    if ~isempty(newCycles)
        efc(n)=sum([newCycles.count].*[newCycles.range])/cfg.Erated;
    else
        efc(n)=0;
    end
end

valid=isfinite(costs);
k=sum(viol(valid));
nValid=sum(valid);
pHat=k/max(nValid,1);
pCI=wilson_interval(k,max(nValid,1),0.05);
mu=mean(costs(valid));
if sum(valid)>1
    sd=std(costs(valid));
    costCI=mu+[-1 1]*1.96*sd/sqrt(sum(valid));
else
    costCI=[nan nan];
end

MC.costs=costs;
MC.voltageViolation=viol;
MC.minimumVoltage=minV;
MC.maxSOCGap=maxSOC;
MC.meanSOCGap=meanSOC;
MC.rainflowPWLcost=cycleCost;
MC.independentRainflowCost=rainflowCost;
MC.degradationRelativeError=degRelError;
MC.EFC=efc;
MC.summary=table(cfg.Nmc,nValid,k,pHat,pCI(1),pCI(2),mu,...
    costCI(1),costCI(2),mean(minV,'omitnan'),max(maxSOC),mean(meanSOC,'omitnan'),...
    mean(degRelError,'omitnan'),mean(efc,'omitnan'),...
    'VariableNames',{'Nrequested','Nvalid','Nviolations','ViolationProbability',...
    'Wilson95Lower','Wilson95Upper','MeanExPostCost','Cost95Lower','Cost95Upper',...
    'MeanMinimumVoltage','MaximumNormalizedSOCGap','MeanNormalizedSOCGap',...
    'MeanRainflowPWLRelativeError','MeanEquivalentFullCycles'});
end

function tf=same_pattern_local(a,b)
tf=numel(a)==numel(b);
if ~tf, return; end
if isempty(a), return; end
A=[[a.i1]' [a.i2]' [a.count]'];
B=[[b.i1]' [b.i2]' [b.count]'];
tf=isequal(size(A),size(B)) && max(abs(A(:)-B(:)))<1e-9;
end
