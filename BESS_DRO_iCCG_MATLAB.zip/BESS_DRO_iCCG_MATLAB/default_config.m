function cfg = default_config()
% Parameters taken from the uploaded manuscript are marked SOURCE.
% Values not stated in the manuscript are marked ASSUMPTION.

cfg.solver = 'cplex';          % SOURCE: MATLAB R2022a / CPLEX 12.10
cfg.verbose = 1;
cfg.solverTimeLimit = 3600;
cfg.randomSeed = 20261127;

% Network base (standard Baran-Wu IEEE-33 feeder)
cfg.baseMVA = 10;              % standard feeder base
cfg.baseKV = 12.66;            % SOURCE
cfg.vMin = 0.95;               % SOURCE
cfg.vMax = 1.05;               % SOURCE
cfg.lMax = 4.0;                % ASSUMPTION: squared-current upper bound

% BESS parameters (SOURCE: manuscript Table 2)
cfg.bessBus = 17;
cfg.Emin = 0.20;
cfg.Emax = 1.80;
cfg.E0 = 1.00;
cfg.Erated = 2.00;
cfg.PchMax = 0.40;
cfg.PdisMax = 0.40;
cfg.etaCh = 0.95;
cfg.etaDis = 0.95;

% PV / DG parameters (SOURCE: manuscript)
cfg.pvBuses = [10 17 24 30];
cfg.pvTotalCapacity = 2.50;
cfg.pvBusCapacity = cfg.pvTotalCapacity/numel(cfg.pvBuses);
cfg.dgBuses = [6 25];
cfg.dgMax = [0.50;0.50];
cfg.dgCost = 58;               % USD/MWh
cfg.curtCost = 75;             % USD/MWh

% PCC and tariffs (SOURCE, time-of-use hours are ASSUMPTION)
cfg.gridImportMax = 2.00;
cfg.gridExportMax = 1.00;
cfg.exportPrice = 40;          % USD/MWh
cfg.importPrice = 80*ones(24,1);
cfg.importPrice(17:21) = 150;  % ASSUMPTION: peak tariff hours

% Multi-timescale scheduling (SOURCE)
cfg.Tda = 24;
cfg.Nid = 96;
cfg.dtDA = 1.0;
cfg.dtID = 0.25;
cfg.trackAllowance = 0.05;     % MWh
cfg.trackPenalty = 250;        % USD/MWh

% Cycle-depth PWL degradation parameters (SOURCE coefficients; revised use
% as cycle-depth segments is a modeling choice that must be calibrated)
cfg.degBreaksMWh = [0.40 0.40 0.40 0.40];
cfg.degMarginal = [2.2 5.0 9.8 18.5];  % USD/MWh
cfg.maxRainflowOuter = 4;

% Copula / uncertainty settings
cfg.rhoTarget = sin(pi/2*(-0.382));  % implied Gaussian rho for empirical tau=-0.382
cfg.arPhi = 0.45;                    % ASSUMPTION: temporal correlation
cfg.pvSigmaFrac = 0.08;              % ASSUMPTION: 8% PV forecast-error scale
cfg.loadSigmaFrac = 0.03;            % ASSUMPTION: 3% load forecast-error scale
cfg.errorClip = 3.0;
cfg.NrawSynthetic = 2000;             % synthetic demo sample, NOT manuscript data
cfg.NscenarioRaw = 300;
cfg.nRepresentative = 20;            % SOURCE: 20 reduced scenarios
cfg.nAdverseExtra = 8;                % ASSUMPTION: finite-support adversarial candidates
cfg.epsilonW = 0.05;                  % SOURCE numerical setting; not calibrated confidence radius

% iCCG settings (SOURCE: manuscript iteration/gap settings, max cuts)
cfg.maxICCG = 30;
cfg.maxCuts = 3;
cfg.initialGapTol = 0.05;
cfg.finalGapTol = 0.001;
cfg.gapShrink = 0.50;
cfg.maxIterations = 50;
cfg.violationTol = 1e-5;

% Evaluation
cfg.runMonteCarlo = true;
cfg.Nmc = 500;                        % required evaluation size; runtime can be high
cfg.runBenchmarks = false;            % optional, potentially very expensive
cfg.outputDir = fullfile(pwd,'BESS_DRO_iCCG_output');

% Optimization numerical settings
cfg.epsNum = 1e-8;
cfg.rainflowPairingTol = 1e-9;
end
