function cycles = rainflow_cycles(E)
% Compact ASTM-style four-point rainflow counting.
% Output fields: i1, i2, range, count (count=1 full, 0.5 half cycle).
E=E(:);
n=numel(E);
if n<3
    cycles=struct('i1',{},'i2',{},'range',{},'count',{});
    return;
end

% Extract turning points while retaining original indices.
d=diff(E);
sg=sign(d);
for k=2:numel(sg)
    if sg(k)==0, sg(k)=sg(k-1); end
end
tp=[1; find(sg(1:end-1).*sg(2:end)<0)+1; n];
tp=unique(tp,'stable');

stack=[];
cycles=struct('i1',{},'i2',{},'range',{},'count',{});
for k=1:numel(tp)
    stack(end+1)=tp(k); %#ok<AGROW>
    while numel(stack)>=3
        nst=numel(stack);
        X=abs(E(stack(nst))-E(stack(nst-1)));
        Y=abs(E(stack(nst-1))-E(stack(nst-2)));
        if X < Y, break; end
        if nst==3
            cycles(end+1)=make_cycle(stack(1),stack(2),E,0.5); %#ok<AGROW>
            stack(1)=[];
        else
            cycles(end+1)=make_cycle(stack(nst-3),stack(nst-2),E,1.0); %#ok<AGROW>
            stack(nst-2:nst-1)=[];
        end
    end
end

% Residual ranges are half cycles.
for k=1:numel(stack)-1
    cycles(end+1)=make_cycle(stack(k),stack(k+1),E,0.5); %#ok<AGROW>
end

% Remove numerically zero ranges.
if ~isempty(cycles)
    keep=[cycles.range] > 1e-8;
    cycles=cycles(keep);
end
end

function c=make_cycle(i1,i2,E,w)
c.i1=i1;
c.i2=i2;
c.range=abs(E(i2)-E(i1));
c.count=w;
end
