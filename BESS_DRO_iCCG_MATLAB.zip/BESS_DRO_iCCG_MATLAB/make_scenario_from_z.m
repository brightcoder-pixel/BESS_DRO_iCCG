function s = make_scenario_from_z(cfg,net,profiles,zPV,zLoad)
% Convert standardized hourly forecast errors into 15-min network profiles.

zPV=zPV(:); zLoad=zLoad(:);
pvSigma=max(0.02,cfg.pvSigmaFrac*profiles.pvTotalDA);
pvTotal=max(0,min(cfg.pvTotalCapacity,profiles.pvTotalDA+pvSigma.*zPV));
loadFactor=max(0.80,1+cfg.loadSigmaFrac*zLoad);

pvHourly=repmat((pvTotal/numel(cfg.pvBuses))',numel(cfg.pvBuses),1);
loadHourly=net.PdMW*(profiles.loadMult.*loadFactor)';
qHourly=net.QdMvar*(profiles.loadMult.*loadFactor)';

s.zPV=zPV;
s.zLoad=zLoad;
s.z=[zPV(:)' zLoad(:)'];
s.pvMW=kron(pvHourly,ones(1,4));
s.loadMW=kron(loadHourly,ones(1,4));
s.loadMvar=kron(qHourly,ones(1,4));
s.name='scenario';
end
