function [C,obj,V] = build_master_model(cfg,net,profiles,candidates,weights,D,...
    cycles,active,mode)
% Master model for finite-support Wasserstein DRO and optional comparators.
% mode: 'DRO', 'SP', 'DET', or 'RO' (finite-support worst case).

T=cfg.Tda;
pCh=sdpvar(T,1); pDis=sdpvar(T,1); E=sdpvar(T+1,1);
uCh=binvar(T,1); uDis=binvar(T,1);
pDG=sdpvar(numel(cfg.dgBuses),T,'full');
pCurt=sdpvar(numel(cfg.pvBuses),T,'full');
pImp=sdpvar(T,1); pExp=sdpvar(T,1);

C=[pCh>=0,pDis>=0,pCh<=cfg.PchMax*uCh,pDis<=cfg.PdisMax*uDis,...
    uCh+uDis<=1,E>=cfg.Emin,E<=cfg.Emax,E(1)==cfg.E0,E(end)==cfg.E0,...
    pDG>=0,pDG<=repmat(cfg.dgMax,1,T),...
    pCurt>=0,pCurt<=profiles.pvDADA,...
    pImp>=0,pImp<=cfg.gridImportMax,pExp>=0,pExp<=cfg.gridExportMax];

for t=1:T
    C=[C,E(t+1)==E(t)+cfg.etaCh*pCh(t)*cfg.dtDA...
        -pDis(t)*cfg.dtDA/cfg.etaDis];
end

[C,nvDA]=add_network_soc(C,cfg,net,profiles.loadDADA,profiles.loadQDA,...
    profiles.pvDADA,pCurt,pDG,pCh,pDis,pImp,pExp);

DAcost=cfg.dtDA*sum(cfg.importPrice.*pImp-cfg.exportPrice*pExp...
    +cfg.dgCost*sum(pDG,1)'+cfg.curtCost*sum(pCurt,1)');

DA.pCh=pCh; DA.pDis=pDis; DA.E=E; DA.uCh=uCh; DA.uDis=uDis;
DA.pDG=pDG; DA.pCurt=pCurt; DA.pImp=pImp; DA.pExp=pExp;

nA=numel(active);
q=sdpvar(nA,1);
for k=1:nA
    j=active(k);
    [C,qExpr,~]=build_recourse_block(C,cfg,net,DA,candidates(j),cycles{j});
    C=[C,q(k)>=qExpr];
end

V.alpha=[]; V.lambda=[]; V.theta=[];
switch upper(mode)
    case 'DRO'
        S=numel(weights);
        alpha=sdpvar(S,1);
        lambda=sdpvar(1,1);
        C=[C,lambda>=0];
        for k=1:nA
            j=active(k);
            for s=1:S
                C=[C,alpha(s)+lambda*D(s,j)>=q(k)];
            end
        end
        obj=DAcost+weights(:)'*alpha+lambda*cfg.epsilonW;
        V.alpha=alpha; V.lambda=lambda;
    case 'SP'
        if numel(active)~=numel(weights)
            error('SP requires all nominal representative scenarios.');
        end
        obj=DAcost+weights(:)'*q;
    case 'DET'
        obj=DAcost+q(1);
    case 'RO'
        theta=sdpvar(1,1);
        C=[C,q<=theta];
        obj=DAcost+theta;
        V.theta=theta;
    otherwise
        error('Unknown risk mode.');
end

V.DA=DA; V.DAcost=DAcost; V.q=q; V.networkDA=nvDA;
V.active=active; V.mode=mode;
end
