function out = solve_iccg_dro(cfg,net,profiles,candidates,weights,D,cycles)
% Finite-support adaptive multi-cut column-and-constraint generation.
% The adversarial support is the finite candidate pool created in
% make_candidate_pool.m. This is a finite-support DRO approximation.

S=numel(weights); M=numel(candidates);
active=1;
LB=-inf; UB=inf;
LBtrace=[]; UBtrace=[]; gapTrace=[]; activeTrace=[];
bestDA=[]; bestRec={}; bestDAcost=nan; bestQ=[];

ops=solver_options(cfg);
for it=1:cfg.maxICCG
    fprintf('iCCG iteration %d; active candidate scenarios = %d\n',it,numel(active));
    [C,obj,V]=build_master_model(cfg,net,profiles,candidates,weights,D,...
        cycles,active,'DRO');
    diagnostics=optimize(C,obj,ops);
    if diagnostics.problem~=0
        error('Master problem failed at iteration %d: %s',it,diagnostics.info);
    end

    LB=max(LB,value(obj));
    DA=extract_DA(V.DA);
    alpha=value(V.alpha);
    lambda=value(V.lambda);
    DAcost=value(V.DAcost);

    Q=zeros(M,1);
    recourse=cell(M,1);
    for j=1:M
        [Q(j),recourse{j}]=solve_recourse(cfg,net,DA,candidates(j),cycles{j});
    end
    if any(~isfinite(Q))
        error('At least one candidate recourse problem is infeasible/unbounded.');
    end

    [worstRec,~]=solve_transport_worstcase(Q,D,weights,cfg.epsilonW);
    UBcandidate=DAcost+worstRec;
    if UBcandidate<UB
        UB=UBcandidate;
        bestDA=DA;
        bestRec=recourse;
        bestDAcost=DAcost;
        bestQ=Q;
    end

    gap=max(0,(UB-LB)/max(abs(UB),cfg.epsNum));
    violation=zeros(M,1);
    for j=1:M
        violation(j)=max(Q(j)-alpha-lambda*D(:,j));
    end

    LBtrace(end+1,1)=LB; %#ok<AGROW>
    UBtrace(end+1,1)=UB; %#ok<AGROW>
    gapTrace(end+1,1)=gap; %#ok<AGROW>
    activeTrace(end+1,1)=numel(active); %#ok<AGROW>

    fprintf('LB %.4f, UB %.4f, gap %.5f, max violation %.5g\n',...
        LB,UB,gap,max(violation));

    if gap<=cfg.finalGapTol && max(violation)<=cfg.violationTol
        break;
    end

    notActive=setdiff(1:M,active);
    [~,ord]=sort(violation(notActive),'descend');
    add=notActive(ord(1:min(cfg.maxCuts,numel(ord))));
    add=add(violation(add)>cfg.violationTol);
    if isempty(add)
        if gap<=cfg.finalGapTol, break; end
        % No violated finite-support columns remain.
        break;
    end
    active=unique([active(:);add(:)])';
end

out.DA=bestDA;
out.DAcost=bestDAcost;
out.recourse=bestRec;
out.Q=bestQ;
out.LB=LB; out.UB=UB;
out.relativeGap=max(0,(UB-LB)/max(abs(UB),cfg.epsNum));
out.iteration=1:numel(LBtrace);
out.LBtrace=LBtrace;
out.UBtrace=UBtrace;
out.gapTrace=gapTrace;
out.activeCountTrace=activeTrace;
out.activeScenarios=active;
out.lambda=lambda;
out.alpha=alpha;
end

function DA=extract_DA(V)
f=fieldnames(V);
for k=1:numel(f)
    DA.(f{k})=value(V.(f{k}));
end
end
