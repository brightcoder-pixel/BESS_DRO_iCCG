function scenarios = generate_joint_scenarios(cfg,net,profiles,copula,N)
% Generate chronological daily trajectories using a Gaussian copula.
% Temporal AR(1) dependence is an explicit synthetic-data assumption.

scenarioCell = cell(N,1);
rho = copula.rho;
phi = cfg.arPhi;
for n=1:N
    e1=randn(cfg.Tda,1);
    e2=randn(cfg.Tda,1);
    zPV=zeros(cfg.Tda,1);
    zL=zeros(cfg.Tda,1);
    zPV(1)=e1(1);
    zL(1)=rho*e1(1)+sqrt(1-rho^2)*e2(1);
    for t=2:cfg.Tda
        zPV(t)=phi*zPV(t-1)+sqrt(1-phi^2)*e1(t);
        innovL=rho*e1(t)+sqrt(1-rho^2)*e2(t);
        zL(t)=phi*zL(t-1)+sqrt(1-phi^2)*innovL;
    end
    zPV=max(-cfg.errorClip,min(cfg.errorClip,zPV));
    zL=max(-cfg.errorClip,min(cfg.errorClip,zL));
    scenarioCell{n}=make_scenario_from_z(cfg,net,profiles,zPV,zL);
    scenarioCell{n}.name=sprintf('raw_%04d',n);
end
scenarios=[scenarioCell{:}];
end
