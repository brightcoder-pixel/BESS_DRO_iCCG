function [cand,D] = make_candidate_pool(cfg,net,profiles,rawScenarios,reps)
% Candidate support consists of 20 reduced representatives plus adverse
% perturbations. The Wasserstein ambiguity-set CENTER is the RAW empirical
% distribution built from all raw daily trajectories (not the centroids).

Sraw=numel(rawScenarios);
Srep=numel(reps);
cand=reps(:);
score=zeros(Srep,1);
for s=1:Srep
    score(s)=mean(reps(s).zLoad-reps(s).zPV);
end
[~,ord]=sort(score,'descend');
nExtra=min(cfg.nAdverseExtra,Srep);
for k=1:nExtra
    base=reps(ord(k));
    zPV=max(-cfg.errorClip,min(cfg.errorClip,base.zPV-0.7));
    zL=max(-cfg.errorClip,min(cfg.errorClip,base.zLoad+0.7));
    extra=make_scenario_from_z(cfg,net,profiles,zPV,zL);
    extra.name=sprintf('adverse_%02d',k);
    cand(end+1,1)=extra; %#ok<AGROW>
end

M=numel(cand);
D=zeros(Sraw,M);
for s=1:Sraw
    for j=1:M
        D(s,j)=mean(abs(rawScenarios(s).z-cand(j).z))/6;
    end
end
end
