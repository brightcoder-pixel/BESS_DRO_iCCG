function [worstValue,gamma] = solve_transport_worstcase(q,D,weights,epsilon)
% Exact finite-support Wasserstein transport LP:
% max sum_{s,j} gamma(s,j)*q(j)
% s.t. sum_j gamma(s,j)=weights(s), sum gamma*D <= epsilon.

S=size(D,1); M=size(D,2);
f=-repmat(q(:)',S,1);
f=f(:);
Aeq=kron(ones(1,M),eye(S));
beq=weights(:);
A=D(:)';
b=epsilon;
lb=zeros(S*M,1);
opts=optimoptions('linprog','Display','none');
[x,~,exitflag]=linprog(f,A,b,Aeq,beq,lb,[],opts);
if exitflag<=0
    error('Wasserstein transport LP failed (linprog exitflag %d).',exitflag);
end
gamma=reshape(x,S,M);
worstValue=sum(sum(gamma.*repmat(q(:)',S,1)));
end
