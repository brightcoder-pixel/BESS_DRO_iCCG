function profiles = make_profiles(cfg,net)
% Clear-day profile matches the manuscript's daily PV energy (18.4 MWh)
% and peak output (2.5 MW). Load multipliers are illustrative assumptions (peak multiplier 0.90 to remain consistent with the 2-MW PCC import cap in this demo).

pvTotal = zeros(24,1);
pvDay = [0.3 0.7 1.2 1.7 2.1 2.4 2.5 2.4 2.1 1.7 1.1 0.2]';
pvTotal(7:18)=pvDay;  % sum = 18.4 MWh for 1-h intervals

loadMult = [0.62 0.60 0.58 0.58 0.60 0.65 0.72 0.78 ...
            0.82 0.84 0.82 0.80 0.78 0.78 0.80 0.83 ...
            0.86 0.89 0.90 0.88 0.84 0.78 0.70 0.65]';

profiles.pvTotalDA = pvTotal;
profiles.pvDADA = repmat((pvTotal/numel(cfg.pvBuses))',numel(cfg.pvBuses),1);
profiles.loadMult = loadMult;
profiles.loadDADA = net.PdMW*loadMult';
profiles.loadQDA = net.QdMvar*loadMult';
profiles.pvBusCapacity = cfg.pvBusCapacity*ones(numel(cfg.pvBuses),1);
profiles.note = 'Clear-day PV profile is manuscript-based; load shape is an illustrative assumption.';
end
