function [Vm,converged] = ac_power_flow_bfs(net,pNetMW,qNetMvar)
% Backward-forward sweep AC power flow for the radial IEEE-33 feeder.
% Positive pNet/qNet denote net consumption; negative active power denotes
% net generation/export.

S=(pNetMW(:)+1i*qNetMvar(:))/net.baseMVA;
V=ones(net.nb,1);
Z=net.r+1i*net.x;
Ibr=zeros(net.ne,1);
converged=false;

for it=1:200
    Vold=V;
    safeV=V;
    small=abs(safeV)<1e-6;
    safeV(small)=1e-6+0i;
    Iload=conj(S./safeV);
    for e=net.edgeReverse
        b=net.to(e);
        child=find(net.from==b);
        Ibr(e)=Iload(b)+sum(Ibr(child));
    end
    V(1)=1+0i;
    for e=net.edgeForward
        i=net.from(e); j=net.to(e);
        V(j)=V(i)-Z(e)*Ibr(e);
    end
    if max(abs(V-Vold))<1e-9
        converged=true;
        break;
    end
end
Vm=abs(V);
end
