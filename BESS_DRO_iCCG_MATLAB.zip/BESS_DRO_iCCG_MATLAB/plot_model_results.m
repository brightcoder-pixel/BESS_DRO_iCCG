function plot_model_results(results,cfg)
% Plot iCCG convergence and a representative BESS energy trajectory.
if ~exist(cfg.outputDir,'dir'), mkdir(cfg.outputDir); end

figure('Color','w');
plot(results.DRO.iteration,results.DRO.LBtrace,'o-','LineWidth',1.5); hold on;
plot(results.DRO.iteration,results.DRO.UBtrace,'s-','LineWidth',1.5);
grid on; xlabel('iCCG iteration'); ylabel('Objective (USD/day)');
legend('Lower bound','Upper bound','Location','best');
title('Finite-support Wasserstein DRO convergence');
saveas(gcf,fullfile(cfg.outputDir,'iCCG_convergence.png'));

if ~isempty(results.DRO.recourse) && ~isempty(results.DRO.recourse{1})
    figure('Color','w');
    plot(0:cfg.dtID:24,results.DRO.recourse{1}.E,'LineWidth',1.5);
    grid on; xlabel('Time (h)'); ylabel('Stored energy (MWh)');
    title('Representative 15-min BESS stored-energy trajectory');
    saveas(gcf,fullfile(cfg.outputDir,'BESS_energy_trajectory.png'));
end

figure('Color','w');
bar(cfg.degMarginal);
grid on; xlabel('Cycle-depth segment'); ylabel('Marginal cost (USD/MWh)');
title('Cycle-depth-dependent PWL degradation coefficients');
saveas(gcf,fullfile(cfg.outputDir,'PWL_degradation_coefficients.png'));
end
