function S = soc_gap_metrics(recourse)
mx=[]; av=[];
for k=1:numel(recourse)
    if isempty(recourse{k}) || ~isfield(recourse{k},'socSlackNormalized'), continue; end
    mx(end+1,1)=max(recourse{k}.socSlackNormalized(:)); %#ok<AGROW>
    av(end+1,1)=mean(recourse{k}.socSlackNormalized(:)); %#ok<AGROW>
end
if isempty(mx)
    S=table(nan,nan,nan,nan,'VariableNames',...
        {'Nrecourse','MaximumNormalizedGap','MeanOfMaximumGaps','MeanNormalizedGap'});
else
    S=table(numel(mx),max(mx),mean(mx),mean(av),...
        'VariableNames',{'Nrecourse','MaximumNormalizedGap','MeanOfMaximumGaps','MeanNormalizedGap'});
end
end
