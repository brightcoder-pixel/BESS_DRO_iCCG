function ops = solver_options(cfg)
ops=sdpsettings('solver',cfg.solver,'verbose',cfg.verbose,...
    'cachesolvers',1,'warning',1);
if strcmpi(cfg.solver,'cplex')
    ops.cplex.display=cfg.verbose;
    ops.cplex.timelimit=cfg.solverTimeLimit;
    ops.cplex.mip.tolerances.mipgap=cfg.finalGapTol;
elseif strcmpi(cfg.solver,'gurobi')
    ops.gurobi.TimeLimit=cfg.solverTimeLimit;
    ops.gurobi.MIPGap=cfg.finalGapTol;
elseif strcmpi(cfg.solver,'mosek')
    ops.mosek.MSK_DPAR_OPTIMIZER_MAX_TIME=cfg.solverTimeLimit;
end
end
