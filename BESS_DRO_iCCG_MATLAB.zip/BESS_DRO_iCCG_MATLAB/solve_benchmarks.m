function B = solve_benchmarks(cfg,net,profiles,candidates,reps,weights,cycles,D)
% Optional comparators using the same finite-support recourse/network model.
% DET: one nominal representative closest to zero.
% SP: expected recourse over all nominal representatives.
% RO: worst recourse over the finite candidate support (not the manuscript's
% original budgeted-polyhedral RO unless its Gamma-set is separately defined).

S=numel(reps); M=numel(candidates);
X=zeros(S,48);
for s=1:S, X(s,:)=reps(s).z; end
[~,detIdx]=min(sum(X.^2,2));

B=struct();
B.DET=solve_one('DET',detIdx);
B.SP=solve_one('SP',1:S);
B.RO=solve_one('RO',1:M);

    function R=solve_one(mode,active)
        [C,obj,V]=build_master_model(cfg,net,profiles,candidates,weights,D,...
            cycles,active,mode);
        diag=optimize(C,obj,solver_options(cfg));
        if diag.problem~=0
            error('%s benchmark failed: %s',mode,diag.info);
        end
        R.objective=value(obj);
        R.DA=extract_local(V.DA);
        R.DAcost=value(V.DAcost);
        R.mode=mode;
        R.activeScenarios=active;
    end
    function DA=extract_local(V)
        f=fieldnames(V);
        for kk=1:numel(f), DA.(f{kk})=value(V.(f{kk})); end
    end
end
