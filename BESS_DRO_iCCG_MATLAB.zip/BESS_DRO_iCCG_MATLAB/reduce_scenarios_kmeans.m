function [reps,weights,info] = reduce_scenarios_kmeans(cfg,net,profiles,raw,K)
% Toolbox-independent Lloyd K-means reduction on 48-dimensional daily errors.

N=numel(raw);
X=zeros(N,48);
for i=1:N, X(i,:)=raw(i).z; end
K=min(K,N);
rng(cfg.randomSeed+11,'twister');
perm=randperm(N,K);
cent=X(perm,:);
labels=ones(N,1);

for it=1:100
    old=labels;
    D=zeros(N,K);
    for k=1:K
        D(:,k)=sum((X-cent(k,:)).^2,2);
    end
    [~,labels]=min(D,[],2);
    for k=1:K
        ix=find(labels==k);
        if isempty(ix)
            [~,worst]=max(min(D,[],2));
            cent(k,:)=X(worst,:);
            labels(worst)=k;
        else
            cent(k,:)=mean(X(ix,:),1);
        end
    end
    if isequal(old,labels), break; end
end

weights=zeros(K,1);
repCell=cell(K,1);
for k=1:K
    ix=find(labels==k);
    weights(k)=numel(ix)/N;
    zPV=cent(k,1:24)';
    zLoad=cent(k,25:48)';
    repCell{k}=make_scenario_from_z(cfg,net,profiles,zPV,zLoad);
    repCell{k}.name=sprintf('representative_%02d',k);
end
reps=[repCell{:}];
weights=weights/sum(weights);
info.labels=labels;
info.centroids=cent;
info.iterations=it;
info.withinClusterSSE=sum(sum((X-cent(labels,:)).^2,2));
end
