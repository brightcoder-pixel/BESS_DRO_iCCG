#!/usr/bin/env python3
"""Run a compact example of the solver-independent iCCG controller."""
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from bess_dro.ccg import (
    AdversarialCandidate,
    CCGConfig,
    MasterSolution,
    run_adaptive_multicut_ccg,
)


def master_solver(scenarios, cuts, gap_tolerance):
    # A compact numerical oracle example for the controller interface.
    lower_bound = 9.9995
    return MasterSolution(
        first_stage={"day_ahead_cost": 5.0, "degradation_cost": 1.0},
        lower_bound=lower_bound,
        day_ahead_cost=5.0,
        degradation_cost=1.0,
        wasserstein_lambda=0.0,
        theta=np.array([4.0]),
    )


def adversarial_solver(master_solution, center_index, center_scenario):
    return [AdversarialCandidate(
        center_index=center_index,
        scenario=np.asarray(center_scenario),
        recourse_cost=4.0,
        wasserstein_distance=0.0,
    )]


if __name__ == "__main__":
    result = run_adaptive_multicut_ccg(
        nominal_probabilities=np.array([1.0]),
        wasserstein_radius=0.05,
        master_solver=master_solver,
        adversarial_solver=adversarial_solver,
        initial_scenarios=[np.zeros((96, 2))],
        config=CCGConfig(),
    )
    print(f"Iterations: {result.iterations}")
    print(f"Lower bound: {result.lower_bound:.6f}")
    print(f"Upper bound: {result.upper_bound:.6f}")
    print(f"Relative gap: {100 * result.relative_gap:.4f}%")
