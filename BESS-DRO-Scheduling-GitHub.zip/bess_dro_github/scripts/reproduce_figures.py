#!/usr/bin/env python3
"""Generate figures directly from the numerical tables reported in the paper."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from bess_dro.plotting import generate_all_reference_figures

if __name__ == "__main__":
    output = ROOT / "outputs" / "reference_figures"
    paths = generate_all_reference_figures(output)
    print(f"Generated {len(paths)} figures in {output}")
    for path in paths:
        print(path.name)
