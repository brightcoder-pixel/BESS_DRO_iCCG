#!/usr/bin/env python3
"""Run the self-contained uncertainty/degradation demonstration workflow."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from bess_dro.config import DEFAULT_CONFIG
from bess_dro.degradation import equal_efc_validation_cases
from bess_dro.plotting import generate_all_reference_figures
from bess_dro.uncertainty import (
    fit_gaussian_copula,
    reduce_daily_trajectories,
    sample_error_trajectories,
)


def main() -> None:
    output_dir = ROOT / "outputs" / "demo"
    output_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(2026)

    # A deterministic demonstration sample with the study's Gaussian-copula parameter.
    rho = DEFAULT_CONFIG.copula_rho
    latent = rng.multivariate_normal(
        [0.0, 0.0], [[1.0, rho], [rho, 1.0]], size=5000
    )
    pv_error_pool = np.clip(0.075 * latent[:, 0], -0.20, 0.20)
    load_error_pool = np.clip(0.040 * latent[:, 1], -0.10, 0.10)
    copula_fit = fit_gaussian_copula(pv_error_pool, load_error_pool)

    daily_errors = sample_error_trajectories(
        n_trajectories=DEFAULT_CONFIG.out_of_sample_trajectories,
        n_intervals=DEFAULT_CONFIG.intraday_intervals,
        pv_marginal_samples=pv_error_pool,
        load_marginal_samples=load_error_pool,
        rho=DEFAULT_CONFIG.copula_rho,
        rng=rng,
    )
    representatives, probabilities, labels = reduce_daily_trajectories(
        daily_errors,
        n_clusters=DEFAULT_CONFIG.representative_scenarios,
        random_state=2026,
    )

    np.save(output_dir / "sampled_error_trajectories.npy", daily_errors)
    np.save(output_dir / "representative_error_trajectories.npy", representatives)
    pd.DataFrame({"scenario": np.arange(1, len(probabilities) + 1),
                  "probability": probabilities}).to_csv(
        output_dir / "representative_scenario_probabilities.csv", index=False
    )
    pd.DataFrame({"trajectory": np.arange(1, len(labels) + 1), "cluster": labels + 1}).to_csv(
        output_dir / "scenario_cluster_assignments.csv", index=False
    )
    with (output_dir / "copula_fit.json").open("w", encoding="utf-8") as f:
        json.dump({
            "rho_estimated": copula_fit.rho,
            "empirical_kendall_tau": copula_fit.kendall_tau_empirical,
            "fitted_kendall_tau": copula_fit.kendall_tau_fitted,
            "sample_count": copula_fit.sample_count,
        }, f, indent=2)

    pd.DataFrame(equal_efc_validation_cases()).to_csv(
        output_dir / "equal_efc_degradation_validation.csv", index=False
    )
    figures = generate_all_reference_figures(output_dir / "reference_figures")

    print(f"Demo outputs written to: {output_dir}")
    print(f"Gaussian copula rho estimate: {copula_fit.rho:.4f}")
    print(f"Representative scenarios: {len(probabilities)}")
    print("Reference figures:")
    for path in figures:
        print(f"  - {path.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
