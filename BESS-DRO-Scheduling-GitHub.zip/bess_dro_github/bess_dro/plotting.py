"""Publication-style plots for the manuscript's reported numerical tables."""
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from .reference_data import load_reference_table


def plot_main_benchmark(output_dir: str | Path) -> Path:
    data = load_reference_table("main_benchmark")
    output = Path(output_dir); output.mkdir(parents=True, exist_ok=True)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.2, 4.6))
    x = np.arange(len(data))
    ax1.bar(x, data["mean_cost_usd_day"], width=0.58)
    ax1.set_ylabel("Mean realized cost (USD/day)")
    ax1.set_xticks(x, data["method"], rotation=12, ha="right")
    ax1.grid(axis="y", alpha=0.25)
    ax2.bar(x, data["voltage_violation_probability_pct"], width=0.58)
    ax2.set_ylabel("Voltage violation probability (%)")
    ax2.set_xticks(x, data["method"], rotation=12, ha="right")
    ax2.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    path = output / "figure_main_benchmark.png"
    fig.savefig(path, dpi=300, bbox_inches="tight"); plt.close(fig)
    return path


def plot_wasserstein_sensitivity(output_dir: str | Path) -> Path:
    data = load_reference_table("wasserstein_sensitivity")
    output = Path(output_dir); output.mkdir(parents=True, exist_ok=True)
    fig, ax1 = plt.subplots(figsize=(7.8, 4.8))
    ax1.plot(data["wasserstein_radius"], data["total_cost_usd_day"], marker="o", linewidth=2)
    ax1.set_xlabel("Wasserstein radius")
    ax1.set_ylabel("Total cost (USD/day)")
    ax1.grid(alpha=0.25)
    ax2 = ax1.twinx()
    ax2.plot(data["wasserstein_radius"], data["minimum_voltage_pu"], marker="s", linestyle="--")
    ax2.set_ylabel("Minimum AC voltage (p.u.)")
    fig.tight_layout()
    path = output / "figure_wasserstein_sensitivity.png"
    fig.savefig(path, dpi=300, bbox_inches="tight"); plt.close(fig)
    return path


def plot_degradation_ablation(output_dir: str | Path) -> Path:
    data = load_reference_table("degradation_ablation")
    output = Path(output_dir); output.mkdir(parents=True, exist_ok=True)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.2, 4.6))
    x = np.arange(len(data))
    ax1.bar(x, data["total_realized_cost_usd_day"], width=0.58)
    ax1.set_ylabel("Total realized cost (USD/day)")
    ax1.set_xticks(x, data["strategy"], rotation=12, ha="right")
    ax1.grid(axis="y", alpha=0.25)
    ax2.bar(x, data["rainflow_degradation_cost_usd_day"], width=0.58)
    ax2.set_ylabel("Rainflow degradation cost (USD/day)")
    ax2.set_xticks(x, data["strategy"], rotation=12, ha="right")
    ax2.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    path = output / "figure_degradation_ablation.png"
    fig.savefig(path, dpi=300, bbox_inches="tight"); plt.close(fig)
    return path


def plot_ccg_performance(output_dir: str | Path) -> Path:
    data = load_reference_table("ccg_runtime")
    output = Path(output_dir); output.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(6.8, 4.6))
    x = np.arange(len(data))
    ax.bar(x, data["runtime_seconds"], width=0.55)
    ax.set_xticks(x, data["algorithm"])
    ax.set_ylabel("Runtime (s)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    path = output / "figure_ccg_runtime.png"
    fig.savefig(path, dpi=300, bbox_inches="tight"); plt.close(fig)
    return path


def generate_all_reference_figures(output_dir: str | Path) -> list[Path]:
    return [
        plot_main_benchmark(output_dir),
        plot_wasserstein_sensitivity(output_dir),
        plot_degradation_ablation(output_dir),
        plot_ccg_performance(output_dir),
    ]
