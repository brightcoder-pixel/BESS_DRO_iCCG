"""Cycle-depth-dependent degradation and Rainflow post-processing."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from .config import DEFAULT_CONFIG, StudyConfig


@dataclass(frozen=True)
class RainflowCycle:
    depth: float
    count: float


def damage_fraction(dod: float | np.ndarray, config: StudyConfig = DEFAULT_CONFIG):
    """Return the piecewise-linear cycle damage fraction g(DoD)."""
    values = np.asarray(dod, dtype=float)
    if np.any(values < -1e-12) or np.any(values > config.dod_breakpoints[-1] + 1e-12):
        raise ValueError("DoD must lie within the 0-80% calibration range.")
    result = np.interp(values, config.dod_breakpoints, config.damage_breakpoints)
    return float(result) if result.ndim == 0 else result


def turning_points(values: np.ndarray) -> np.ndarray:
    """Extract the endpoints and internal peaks/valleys of a sequence."""
    x = np.asarray(values, dtype=float).reshape(-1)
    if x.size < 2 or not np.isfinite(x).all():
        raise ValueError("A finite sequence with at least two samples is required.")
    compact = x[np.r_[True, np.diff(x) != 0.0]]
    if compact.size <= 2:
        return compact.copy()
    points = [compact[0]]
    for i in range(1, compact.size - 1):
        left = compact[i] - compact[i - 1]
        right = compact[i + 1] - compact[i]
        if left * right < 0.0:
            points.append(compact[i])
    points.append(compact[-1])
    return np.asarray(points, dtype=float)


def peak_valley_surrogate(soc: np.ndarray, config: StudyConfig = DEFAULT_CONFIG) -> float:
    """Rainflow-inspired adjacent peak-valley excursion damage surrogate.

    Each adjacent turning-point excursion contributes one half-cycle damage.
    """
    points = turning_points(soc)
    excursion_depths = np.abs(np.diff(points))
    return float(0.5 * np.sum(damage_fraction(excursion_depths, config)))


def rainflow_count(soc: np.ndarray) -> list[RainflowCycle]:
    """ASTM-style four-point Rainflow counting with residual half cycles."""
    points = turning_points(soc)
    stack: list[float] = []
    cycles: list[RainflowCycle] = []
    for value in points:
        stack.append(float(value))
        while len(stack) >= 3:
            newer_range = abs(stack[-1] - stack[-2])
            older_range = abs(stack[-2] - stack[-3])
            if newer_range < older_range:
                break
            if len(stack) == 3:
                cycles.append(RainflowCycle(older_range, 0.5))
                stack.pop(0)
            else:
                cycles.append(RainflowCycle(older_range, 1.0))
                del stack[-3:-1]
    for left, right in zip(stack[:-1], stack[1:]):
        cycles.append(RainflowCycle(abs(right - left), 0.5))
    return cycles


def rainflow_damage(soc: np.ndarray, config: StudyConfig = DEFAULT_CONFIG) -> float:
    """Cumulative Rainflow damage for a realized SOC trajectory."""
    cycles = rainflow_count(soc)
    return float(sum(c.count * damage_fraction(c.depth, config) for c in cycles))


def degradation_cost(damage: float, config: StudyConfig = DEFAULT_CONFIG) -> float:
    """Convert cumulative damage to a monetary replacement-cost share."""
    if damage < 0:
        raise ValueError("damage must be nonnegative.")
    return float(config.net_replacement_cost_usd * damage)


def equivalent_full_cycles(energy_mwh: np.ndarray, config: StudyConfig = DEFAULT_CONFIG) -> float:
    """Calculate EFC using the rated-energy basis in Eq. (21)."""
    energy = np.asarray(energy_mwh, dtype=float).reshape(-1)
    if energy.size < 2 or not np.isfinite(energy).all():
        raise ValueError("energy_mwh must contain at least two finite samples.")
    return float(np.sum(np.abs(np.diff(energy))) / (2.0 * config.energy_rated_mwh))


def equal_efc_validation_cases(config: StudyConfig = DEFAULT_CONFIG) -> list[dict]:
    """Return the three equal-EFC SOC trajectories reported in the manuscript."""
    cases = {
        "A_deep_excursions": np.array([0.50, 0.10, 0.70, 0.10, 0.50]),
        "B_repeated_shallow": np.array([0.50, 0.70, 0.50, 0.70, 0.50, 0.70, 0.50,
                                         0.70, 0.50, 0.70, 0.50]),
        "C_nested_cycle": np.array([0.50, 0.30, 0.70, 0.30, 0.70, 0.30, 0.50]),
    }
    rows = []
    for name, soc in cases.items():
        energy = soc * config.energy_rated_mwh
        rf_damage = rainflow_damage(soc, config)
        surrogate_damage = peak_valley_surrogate(soc, config)
        rows.append({
            "case": name,
            "efc": equivalent_full_cycles(energy, config),
            "rainflow_damage": rf_damage,
            "surrogate_damage": surrogate_damage,
            "relative_deviation_pct": 100.0 * abs(surrogate_damage - rf_damage) / rf_damage,
            "rainflow_cost_usd": degradation_cost(rf_damage, config),
            "surrogate_cost_usd": degradation_cost(surrogate_damage, config),
        })
    return rows
