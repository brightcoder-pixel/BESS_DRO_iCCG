"""Numerical settings reported in the accompanying manuscript."""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class StudyConfig:
    # Time scales
    day_ahead_hours: int = 24
    intraday_intervals: int = 96
    intraday_dt_h: float = 0.25

    # BESS
    energy_rated_mwh: float = 2.0
    energy_min_mwh: float = 0.2
    energy_max_mwh: float = 1.8
    charge_power_max_mw: float = 0.4
    discharge_power_max_mw: float = 0.4
    charge_efficiency: float = 0.95
    discharge_efficiency: float = 0.95
    initial_energy_mwh: float = 1.0
    terminal_energy_mwh: float = 1.0
    soc_min: float = 0.10
    soc_max: float = 0.90

    # Battery degradation
    dod_breakpoints: tuple = (0.0, 0.2, 0.4, 0.6, 0.8)
    cycle_life: tuple = (float("inf"), 15000.0, 10000.0, 8000.0, 6000.0)
    replacement_cost_usd: float = 200000.0
    residual_value_usd: float = 20000.0
    reference_temperature_c: float = 25.0
    end_of_life_soh: float = 0.80

    # Network and DER configuration
    base_voltage_kv: float = 12.66
    base_power_mva: float = 10.0
    total_base_load_mw: float = 3.715
    total_base_reactive_load_mvar: float = 2.30
    pv_buses: tuple = (10, 17, 24, 30)
    pv_capacity_mw: tuple = (0.55, 0.65, 0.60, 0.70)
    dg_buses: tuple = (6, 25)
    dg_capacity_mw: tuple = (0.5, 0.5)
    bess_bus: int = 17

    # Economic settings
    grid_import_limit_mw: float = 2.0
    grid_export_limit_mw: float = 1.0
    import_price_offpeak_usd_mwh: float = 80.0
    import_price_peak_usd_mwh: float = 150.0
    export_price_usd_mwh: float = 40.0
    dg_cost_usd_mwh: float = 58.0
    pv_curtailment_penalty_usd_mwh: float = 75.0

    # Uncertainty and DRO
    copula_rho: float = -0.51
    wasserstein_radius: float = 0.05
    representative_scenarios: int = 20
    out_of_sample_trajectories: int = 500
    pv_error_lower: float = -0.20
    pv_error_upper: float = 0.20
    load_error_lower: float = -0.10
    load_error_upper: float = 0.10

    # Intraday coordination
    energy_tracking_tolerance_mwh: float = 0.05
    tracking_penalty_usd_mwh: float = 250.0

    # Network security
    voltage_min_pu: float = 0.95
    voltage_max_pu: float = 1.05

    # iCCG
    initial_gap: float = 0.05
    final_gap: float = 0.001
    gap_shrink_factor: float = 0.50
    max_iterations: int = 50
    max_cuts_per_iteration: int = 3
    numerical_epsilon: float = 1e-6

    @property
    def net_replacement_cost_usd(self) -> float:
        return self.replacement_cost_usd - self.residual_value_usd

    @property
    def damage_breakpoints(self) -> np.ndarray:
        values = [0.0]
        for life in self.cycle_life[1:]:
            values.append(1.0 / life)
        return np.asarray(values, dtype=float)


DEFAULT_CONFIG = StudyConfig()
