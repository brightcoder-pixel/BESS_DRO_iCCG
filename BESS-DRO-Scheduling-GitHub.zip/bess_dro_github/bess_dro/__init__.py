"""Computational companion for correlation- and degradation-aware BESS scheduling."""
from .config import DEFAULT_CONFIG, StudyConfig
from .degradation import (
    damage_fraction,
    peak_valley_surrogate,
    rainflow_count,
    rainflow_damage,
    equivalent_full_cycles,
    equal_efc_validation_cases,
)
from .coordination import interpolate_hourly_energy, tracking_slack, tracking_penalty_usd
from .uncertainty import (
    fit_gaussian_copula,
    sample_gaussian_copula,
    sample_error_trajectories,
    reduce_daily_trajectories,
    reconstruct_actual_trajectories,
)
from .wasserstein import wasserstein_ground_distance, finite_support_worst_case_expectation

__all__ = [
    "DEFAULT_CONFIG", "StudyConfig", "damage_fraction", "peak_valley_surrogate",
    "rainflow_count", "rainflow_damage", "equivalent_full_cycles",
    "equal_efc_validation_cases", "interpolate_hourly_energy", "tracking_slack",
    "tracking_penalty_usd", "fit_gaussian_copula", "sample_gaussian_copula",
    "sample_error_trajectories", "reduce_daily_trajectories",
    "reconstruct_actual_trajectories", "wasserstein_ground_distance",
    "finite_support_worst_case_expectation",
]
