"""Adaptive multi-cut column-and-constraint generation controller."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Any
import numpy as np


@dataclass(frozen=True)
class CCGConfig:
    initial_gap: float = 0.05
    final_gap: float = 0.001
    shrink_factor: float = 0.50
    max_iterations: int = 50
    max_cuts_per_iteration: int = 3
    numerical_epsilon: float = 1e-6


@dataclass
class MasterSolution:
    first_stage: Any
    lower_bound: float
    day_ahead_cost: float
    degradation_cost: float
    wasserstein_lambda: float
    theta: np.ndarray


@dataclass(frozen=True)
class AdversarialCandidate:
    center_index: int
    scenario: np.ndarray
    recourse_cost: float
    wasserstein_distance: float


@dataclass(frozen=True)
class GeneratedCut:
    center_index: int
    scenario: np.ndarray
    recourse_cost: float
    wasserstein_distance: float
    violation: float


@dataclass
class CCGResult:
    lower_bound: float
    upper_bound: float
    relative_gap: float
    iterations: int
    cuts: list[GeneratedCut] = field(default_factory=list)
    history: list[dict] = field(default_factory=list)
    master_solution: MasterSolution | None = None


def run_adaptive_multicut_ccg(
    nominal_probabilities: np.ndarray,
    wasserstein_radius: float,
    master_solver: Callable,
    adversarial_solver: Callable,
    initial_scenarios: list[np.ndarray],
    config: CCGConfig = CCGConfig(),
) -> CCGResult:
    """Run the adaptive multi-cut iCCG controller with user-supplied oracles.

    ``master_solver(scenarios, cuts, gap_tolerance)`` returns a MasterSolution.
    ``adversarial_solver(master_solution, center_index, center_scenario)`` returns
    a list of AdversarialCandidate objects for that nominal center.
    """
    probabilities = np.asarray(nominal_probabilities, dtype=float).reshape(-1)
    if len(initial_scenarios) != probabilities.size:
        raise ValueError("One initial scenario is required for each nominal probability.")
    if np.any(probabilities < 0) or not np.isclose(probabilities.sum(), 1.0):
        raise ValueError("Nominal probabilities must be nonnegative and sum to one.")
    if wasserstein_radius < 0:
        raise ValueError("wasserstein_radius must be nonnegative.")
    if not (0 < config.final_gap <= config.initial_gap):
        raise ValueError("Gap tolerances must satisfy 0 < final_gap <= initial_gap.")
    if not (0 < config.shrink_factor < 1):
        raise ValueError("shrink_factor must lie between zero and one.")

    scenarios = [np.asarray(s, dtype=float).copy() for s in initial_scenarios]
    cuts: list[GeneratedCut] = []
    lower_bound = -np.inf
    upper_bound = np.inf
    tolerance = config.initial_gap
    history: list[dict] = []
    latest_master: MasterSolution | None = None

    for iteration in range(1, config.max_iterations + 1):
        latest_master = master_solver(scenarios, cuts, tolerance)
        lower_bound = max(lower_bound, float(latest_master.lower_bound))
        theta = np.asarray(latest_master.theta, dtype=float).reshape(-1)
        if theta.size != probabilities.size:
            raise ValueError("MasterSolution.theta must have one value per nominal center.")

        candidates_by_center: list[list[AdversarialCandidate]] = []
        all_violations: list[GeneratedCut] = []
        worst_case_terms = np.zeros(probabilities.size, dtype=float)
        for center_index, center in enumerate(scenarios):
            candidates = adversarial_solver(latest_master, center_index, center)
            if not candidates:
                raise RuntimeError(f"Adversarial oracle returned no candidates for center {center_index}.")
            candidates_by_center.append(candidates)
            scored = []
            for candidate in candidates:
                phi = float(candidate.recourse_cost) - latest_master.wasserstein_lambda * float(candidate.wasserstein_distance)
                scored.append((phi, candidate))
                violation = phi - theta[center_index]
                if violation > 0:
                    all_violations.append(GeneratedCut(
                        center_index=center_index,
                        scenario=np.asarray(candidate.scenario, dtype=float).copy(),
                        recourse_cost=float(candidate.recourse_cost),
                        wasserstein_distance=float(candidate.wasserstein_distance),
                        violation=float(violation),
                    ))
            worst_case_terms[center_index] = max(value for value, _ in scored)

        upper_candidate = (
            latest_master.day_ahead_cost
            + latest_master.degradation_cost
            + wasserstein_radius * latest_master.wasserstein_lambda
            + float(np.dot(probabilities, worst_case_terms))
        )
        upper_bound = min(upper_bound, upper_candidate)
        gap = (upper_bound - lower_bound) / max(abs(upper_bound), config.numerical_epsilon)
        gap = max(float(gap), 0.0)
        history.append({
            "iteration": iteration,
            "lower_bound": lower_bound,
            "upper_bound": upper_bound,
            "relative_gap": gap,
            "gap_tolerance": tolerance,
            "generated_cuts": len(all_violations),
        })

        if gap <= config.final_gap:
            break

        all_violations.sort(key=lambda item: item.violation, reverse=True)
        selected = all_violations[:config.max_cuts_per_iteration]
        for cut in selected:
            cuts.append(cut)
            scenarios.append(cut.scenario.copy())
        tolerance = max(config.final_gap, config.shrink_factor * tolerance)

    return CCGResult(
        lower_bound=float(lower_bound),
        upper_bound=float(upper_bound),
        relative_gap=float(history[-1]["relative_gap"]),
        iterations=len(history),
        cuts=cuts,
        history=history,
        master_solution=latest_master,
    )
