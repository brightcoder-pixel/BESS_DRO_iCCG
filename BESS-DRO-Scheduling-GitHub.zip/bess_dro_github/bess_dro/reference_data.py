"""Access to numerical tables transcribed from the accompanying manuscript."""
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "reference"


def load_reference_table(name: str) -> pd.DataFrame:
    path = DATA_DIR / f"{name}.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Reference table not found: {path}")
    return pd.read_csv(path)


def available_reference_tables() -> list[str]:
    return sorted(path.stem for path in DATA_DIR.glob("*.csv"))
