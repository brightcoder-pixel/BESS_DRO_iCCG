"""Copula-based joint PV-load forecast-error modeling and scenario reduction."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
import numpy as np
from scipy.stats import kendalltau, norm, rankdata
from sklearn.cluster import KMeans


@dataclass(frozen=True)
class GaussianCopulaFit:
    rho: float
    kendall_tau_empirical: float
    kendall_tau_fitted: float
    sample_count: int


def fit_gaussian_copula(pv_errors: np.ndarray, load_errors: np.ndarray) -> GaussianCopulaFit:
    """Estimate a Gaussian copula parameter from paired normalized errors."""
    pv = np.asarray(pv_errors, dtype=float).reshape(-1)
    load = np.asarray(load_errors, dtype=float).reshape(-1)
    if pv.shape != load.shape or pv.size < 3:
        raise ValueError("PV and load error samples must have the same length (at least 3).")
    if not np.isfinite(pv).all() or not np.isfinite(load).all():
        raise ValueError("Forecast-error samples must be finite.")

    n = pv.size
    u_pv = (rankdata(pv, method="average") - 0.5) / n
    u_load = (rankdata(load, method="average") - 0.5) / n
    z_pv = norm.ppf(np.clip(u_pv, 1e-8, 1.0 - 1e-8))
    z_load = norm.ppf(np.clip(u_load, 1e-8, 1.0 - 1e-8))
    rho = float(np.corrcoef(z_pv, z_load)[0, 1])
    tau_empirical = float(kendalltau(pv, load, variant="b").statistic)
    tau_fitted = float(2.0 / np.pi * np.arcsin(np.clip(rho, -1.0, 1.0)))
    return GaussianCopulaFit(rho, tau_empirical, tau_fitted, n)


def sample_gaussian_copula(
    n_samples: int,
    pv_marginal_samples: np.ndarray,
    load_marginal_samples: np.ndarray,
    rho: float = -0.51,
    rng: Optional[np.random.Generator] = None,
) -> np.ndarray:
    """Sample paired errors using empirical marginals and a Gaussian copula.

    Returns an (n_samples, 2) array whose columns are PV and load errors.
    """
    if n_samples < 1:
        raise ValueError("n_samples must be positive.")
    pv = np.asarray(pv_marginal_samples, dtype=float).reshape(-1)
    load = np.asarray(load_marginal_samples, dtype=float).reshape(-1)
    if pv.size < 2 or load.size < 2:
        raise ValueError("Each empirical marginal must contain at least two samples.")
    if not -0.999 < rho < 0.999:
        raise ValueError("rho must lie strictly between -0.999 and 0.999.")
    rng = rng or np.random.default_rng()
    covariance = np.array([[1.0, rho], [rho, 1.0]], dtype=float)
    latent = rng.multivariate_normal(np.zeros(2), covariance, size=n_samples)
    uniforms = norm.cdf(latent)
    pv_draws = np.quantile(pv, uniforms[:, 0], method="linear")
    load_draws = np.quantile(load, uniforms[:, 1], method="linear")
    return np.column_stack((pv_draws, load_draws))


def sample_error_trajectories(
    n_trajectories: int,
    n_intervals: int,
    pv_marginal_samples: np.ndarray,
    load_marginal_samples: np.ndarray,
    rho: float = -0.51,
    rng: Optional[np.random.Generator] = None,
) -> np.ndarray:
    """Generate daily paired error trajectories with contemporaneous dependence."""
    draws = sample_gaussian_copula(
        n_trajectories * n_intervals,
        pv_marginal_samples,
        load_marginal_samples,
        rho,
        rng,
    )
    return draws.reshape(n_trajectories, n_intervals, 2)


def reconstruct_actual_trajectories(
    pv_forecast_mw: np.ndarray,
    load_forecast_mw: np.ndarray,
    normalized_errors: np.ndarray,
    pv_rated_mw: float,
    load_base_mw: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Reconstruct physical PV and load trajectories from normalized errors."""
    pv_forecast = np.asarray(pv_forecast_mw, dtype=float).reshape(-1)
    load_forecast = np.asarray(load_forecast_mw, dtype=float).reshape(-1)
    errors = np.asarray(normalized_errors, dtype=float)
    if errors.shape[-1] != 2 or errors.shape[-2] != pv_forecast.size:
        raise ValueError("normalized_errors must have shape (..., T, 2), matching the forecasts.")
    if load_forecast.size != pv_forecast.size:
        raise ValueError("PV and load forecasts must have the same horizon.")
    pv_actual = pv_forecast + errors[..., 0] * pv_rated_mw
    load_actual = load_forecast + errors[..., 1] * load_base_mw
    pv_actual = np.clip(pv_actual, 0.0, pv_rated_mw)
    load_actual = np.maximum(load_actual, 0.0)
    return pv_actual, load_actual


def reduce_daily_trajectories(
    trajectories: np.ndarray,
    n_clusters: int = 20,
    random_state: int = 2026,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Reduce complete daily PV-load error trajectories by K-means.

    Parameters
    ----------
    trajectories:
        Array with shape (n_days, n_intervals, 2).

    Returns
    -------
    representatives, probabilities, labels
        Centroid trajectories, cluster probabilities, and original labels.
    """
    data = np.asarray(trajectories, dtype=float)
    if data.ndim != 3 or data.shape[2] != 2:
        raise ValueError("trajectories must have shape (n_days, n_intervals, 2).")
    if not 1 <= n_clusters <= data.shape[0]:
        raise ValueError("n_clusters must be between 1 and the number of trajectories.")
    n_days, n_intervals, _ = data.shape
    model = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    labels = model.fit_predict(data.reshape(n_days, -1))
    representatives = model.cluster_centers_.reshape(n_clusters, n_intervals, 2)
    counts = np.bincount(labels, minlength=n_clusters).astype(float)
    probabilities = counts / counts.sum()
    return representatives, probabilities, labels
