"""Wasserstein ground metric and finite-support ambiguity-set evaluation."""
from __future__ import annotations
import numpy as np
from scipy.optimize import linprog


def wasserstein_ground_distance(a: np.ndarray, b: np.ndarray) -> float:
    """Equally weighted L1 ground metric for normalized 24-h PV-load errors.

    d(xi, xi_s) = 1/(2T) * sum_t(|eps_PV,t-eps_PV,s,t| + |eps_L,t-eps_L,s,t|).
    """
    x = np.asarray(a, dtype=float)
    y = np.asarray(b, dtype=float)
    if x.shape != y.shape or x.ndim != 2 or x.shape[1] != 2:
        raise ValueError("Both trajectories must have shape (T, 2).")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Trajectories must be finite.")
    return float(np.abs(x - y).sum() / (2.0 * x.shape[0]))


def finite_support_worst_case_expectation(
    candidate_trajectories: np.ndarray,
    nominal_trajectories: np.ndarray,
    nominal_probabilities: np.ndarray,
    recourse_costs: np.ndarray,
    radius: float,
) -> tuple[float, np.ndarray]:
    """Solve a finite-support Wasserstein worst-case expectation by transport LP.

    Transport mass is moved from each nominal representative scenario to the
    candidate support. The transport budget is measured with the manuscript's
    equally weighted L1 trajectory metric.
    """
    candidates = np.asarray(candidate_trajectories, dtype=float)
    nominal = np.asarray(nominal_trajectories, dtype=float)
    probs = np.asarray(nominal_probabilities, dtype=float).reshape(-1)
    costs = np.asarray(recourse_costs, dtype=float).reshape(-1)
    if candidates.ndim != 3 or nominal.ndim != 3 or candidates.shape[1:] != nominal.shape[1:]:
        raise ValueError("Candidate and nominal trajectories must have compatible (N, T, 2) shapes.")
    if costs.size != candidates.shape[0] or probs.size != nominal.shape[0]:
        raise ValueError("Cost and probability vectors must match their trajectory sets.")
    if np.any(probs < 0) or not np.isclose(probs.sum(), 1.0):
        raise ValueError("Nominal probabilities must be nonnegative and sum to one.")
    if radius < 0:
        raise ValueError("radius must be nonnegative.")

    n_cand, n_nom = candidates.shape[0], nominal.shape[0]
    distances = np.empty((n_cand, n_nom), dtype=float)
    for i in range(n_cand):
        for j in range(n_nom):
            distances[i, j] = wasserstein_ground_distance(candidates[i], nominal[j])

    # pi[i,j] is transported probability from nominal atom j to candidate atom i.
    objective = -np.repeat(costs, n_nom)
    a_eq = np.zeros((n_nom, n_cand * n_nom), dtype=float)
    for j in range(n_nom):
        a_eq[j, j::n_nom] = 1.0
    b_eq = probs
    a_ub = distances.reshape(1, -1)
    b_ub = np.array([radius], dtype=float)
    result = linprog(
        objective,
        A_ub=a_ub,
        b_ub=b_ub,
        A_eq=a_eq,
        b_eq=b_eq,
        bounds=(0.0, None),
        method="highs",
    )
    if not result.success:
        raise RuntimeError(f"Wasserstein transport LP failed: {result.message}")
    transport = result.x.reshape(n_cand, n_nom)
    return float(-result.fun), transport
