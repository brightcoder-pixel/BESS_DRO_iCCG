"""Backward-forward sweep power flow for the radial IEEE 33-bus feeder.

The feeder base data follow the Baran-Wu 33-bus case distributed with MATPOWER.
DER locations and capacities follow the accompanying study configuration.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .config import DEFAULT_CONFIG, StudyConfig


# First 32 normally closed branches of the Baran-Wu 33-bus radial feeder (ohms).
_BRANCH_OHM = np.array([
    [1, 2, 0.0922, 0.0470], [2, 3, 0.4930, 0.2511], [3, 4, 0.3660, 0.1864],
    [4, 5, 0.3811, 0.1941], [5, 6, 0.8190, 0.7070], [6, 7, 0.1872, 0.6188],
    [7, 8, 0.7114, 0.2351], [8, 9, 1.0300, 0.7400], [9, 10, 1.0440, 0.7400],
    [10, 11, 0.1966, 0.0650], [11, 12, 0.3744, 0.1238], [12, 13, 1.4680, 1.1550],
    [13, 14, 0.5416, 0.7129], [14, 15, 0.5910, 0.5260], [15, 16, 0.7463, 0.5450],
    [16, 17, 1.2890, 1.7210], [17, 18, 0.7320, 0.5740], [2, 19, 0.1640, 0.1565],
    [19, 20, 1.5042, 1.3554], [20, 21, 0.4095, 0.4784], [21, 22, 0.7089, 0.9373],
    [3, 23, 0.4512, 0.3083], [23, 24, 0.8980, 0.7091], [24, 25, 0.8960, 0.7011],
    [6, 26, 0.2030, 0.1034], [26, 27, 0.2842, 0.1447], [27, 28, 1.0590, 0.9337],
    [28, 29, 0.8042, 0.7006], [29, 30, 0.5075, 0.2585], [30, 31, 0.9744, 0.9630],
    [31, 32, 0.3105, 0.3619], [32, 33, 0.3410, 0.5302],
], dtype=float)

# Bus active/reactive demands in kW/kVAr from MATPOWER case33bw.
_BUS_LOAD_KW_KVAR = np.array([
    [0, 0], [100, 60], [90, 40], [120, 80], [60, 30], [60, 20], [200, 100],
    [200, 100], [60, 20], [60, 20], [45, 30], [60, 35], [60, 35], [120, 80],
    [60, 10], [60, 20], [60, 20], [90, 40], [90, 40], [90, 40], [90, 40],
    [90, 40], [90, 50], [420, 200], [420, 200], [60, 25], [60, 25], [60, 20],
    [120, 70], [200, 600], [150, 70], [210, 100], [60, 40],
], dtype=float)


@dataclass(frozen=True)
class PowerFlowResult:
    voltage_pu: np.ndarray
    branch_current_pu: np.ndarray
    converged: bool
    iterations: int
    losses_mw: float

    @property
    def minimum_voltage_pu(self) -> float:
        return float(np.min(self.voltage_pu))

    @property
    def maximum_voltage_pu(self) -> float:
        return float(np.max(self.voltage_pu))


def ieee33_loads() -> tuple[np.ndarray, np.ndarray]:
    """Return the 33-bus base active and reactive load vectors in MW/Mvar."""
    return _BUS_LOAD_KW_KVAR[:, 0] / 1000.0, _BUS_LOAD_KW_KVAR[:, 1] / 1000.0


def _radial_order() -> tuple[list[int], list[list[int]], np.ndarray]:
    n_bus = 33
    children: list[list[int]] = [[] for _ in range(n_bus)]
    parent_branch = np.full(n_bus, -1, dtype=int)
    for k, (from_bus, to_bus, _, _) in enumerate(_BRANCH_OHM):
        i, j = int(from_bus) - 1, int(to_bus) - 1
        children[i].append(j)
        parent_branch[j] = k
    order = [0]
    for bus in order:
        order.extend(children[bus])
    if len(order) != n_bus:
        raise RuntimeError("The feeder branch data do not form a connected radial tree.")
    return order, children, parent_branch


def backward_forward_sweep(
    p_load_mw: np.ndarray | None = None,
    q_load_mvar: np.ndarray | None = None,
    pv_generation_mw: np.ndarray | None = None,
    dg_generation_mw: np.ndarray | None = None,
    bess_discharge_mw: np.ndarray | None = None,
    config: StudyConfig = DEFAULT_CONFIG,
    tolerance: float = 1e-10,
    max_iterations: int = 200,
) -> PowerFlowResult:
    """Run a single-phase-equivalent balanced radial AC power-flow sweep.

    Positive DER and BESS values denote generation/discharge and reduce net load.
    All vectors are indexed by bus number minus one and contain 33 entries.
    """
    base_p, base_q = ieee33_loads()
    p_load = base_p.copy() if p_load_mw is None else np.asarray(p_load_mw, dtype=float).reshape(-1)
    q_load = base_q.copy() if q_load_mvar is None else np.asarray(q_load_mvar, dtype=float).reshape(-1)
    if p_load.size != 33 or q_load.size != 33:
        raise ValueError("Load vectors must contain 33 bus entries.")

    def vector_or_zero(value):
        if value is None:
            return np.zeros(33, dtype=float)
        array = np.asarray(value, dtype=float).reshape(-1)
        if array.size != 33:
            raise ValueError("DER vectors must contain 33 bus entries.")
        return array

    pv = vector_or_zero(pv_generation_mw)
    dg = vector_or_zero(dg_generation_mw)
    bess = vector_or_zero(bess_discharge_mw)
    p_net = p_load - pv - dg - bess
    q_net = q_load

    z_base_ohm = config.base_voltage_kv ** 2 / config.base_power_mva
    branch_z = (_BRANCH_OHM[:, 2] + 1j * _BRANCH_OHM[:, 3]) / z_base_ohm
    branch_from = _BRANCH_OHM[:, 0].astype(int) - 1
    branch_to = _BRANCH_OHM[:, 1].astype(int) - 1
    order, children, parent_branch = _radial_order()
    voltage = np.ones(33, dtype=complex)
    branch_current = np.zeros(32, dtype=complex)
    converged = False

    for iteration in range(1, max_iterations + 1):
        node_current = np.zeros(33, dtype=complex)
        s_net_pu = (p_net + 1j * q_net) / config.base_power_mva
        node_current[1:] = np.conj(s_net_pu[1:] / voltage[1:])

        for bus in reversed(order[1:]):
            k = parent_branch[bus]
            branch_current[k] = node_current[bus] + sum(
                branch_current[parent_branch[ch]] for ch in children[bus]
            )

        new_voltage = np.ones(33, dtype=complex)
        for bus in order[1:]:
            k = parent_branch[bus]
            parent = branch_from[k]
            new_voltage[bus] = new_voltage[parent] - branch_z[k] * branch_current[k]

        if np.max(np.abs(new_voltage - voltage)) < tolerance:
            voltage = new_voltage
            converged = True
            break
        voltage = new_voltage

    losses_pu = float(np.sum(np.abs(branch_current) ** 2 * branch_z.real))
    losses_mw = losses_pu * config.base_power_mva
    return PowerFlowResult(np.abs(voltage), branch_current.copy(), converged, iteration, losses_mw)
