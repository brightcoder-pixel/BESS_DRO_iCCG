"""Hourly day-ahead to 15-minute intraday stored-energy coordination."""
from __future__ import annotations
import numpy as np
from .config import DEFAULT_CONFIG, StudyConfig


def interpolate_hourly_energy(
    hourly_energy_mwh: np.ndarray,
    config: StudyConfig = DEFAULT_CONFIG,
) -> np.ndarray:
    """Linearly interpolate 25 hourly boundary values to 97 quarter-hour points."""
    energy = np.asarray(hourly_energy_mwh, dtype=float).reshape(-1)
    expected = config.day_ahead_hours + 1
    if energy.size != expected:
        raise ValueError(f"hourly_energy_mwh must contain {expected} boundary values.")
    if not np.isfinite(energy).all():
        raise ValueError("hourly_energy_mwh must be finite.")
    source_time = np.arange(expected, dtype=float)
    target_time = np.arange(config.intraday_intervals + 1, dtype=float) / 4.0
    return np.interp(target_time, source_time, energy)


def tracking_slack(
    actual_energy_mwh: np.ndarray,
    reference_energy_mwh: np.ndarray,
    tolerance_mwh: float | None = None,
    config: StudyConfig = DEFAULT_CONFIG,
) -> np.ndarray:
    """Positive deviation beyond the permitted stored-energy tracking band."""
    actual = np.asarray(actual_energy_mwh, dtype=float)
    reference = np.asarray(reference_energy_mwh, dtype=float)
    if actual.shape != reference.shape:
        raise ValueError("Actual and reference energy trajectories must have identical shapes.")
    tol = config.energy_tracking_tolerance_mwh if tolerance_mwh is None else tolerance_mwh
    return np.maximum(np.abs(actual - reference) - tol, 0.0)


def tracking_penalty_usd(
    actual_energy_mwh: np.ndarray,
    reference_energy_mwh: np.ndarray,
    config: StudyConfig = DEFAULT_CONFIG,
) -> float:
    """Calculate the intraday trajectory tracking penalty."""
    slack = tracking_slack(actual_energy_mwh, reference_energy_mwh, config=config)
    return float(config.tracking_penalty_usd_mwh * np.sum(slack))
