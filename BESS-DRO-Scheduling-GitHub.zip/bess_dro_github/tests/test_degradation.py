import numpy as np
from bess_dro.config import DEFAULT_CONFIG
from bess_dro.degradation import (
    damage_fraction, equal_efc_validation_cases, equivalent_full_cycles,
    peak_valley_surrogate, rainflow_damage,
)


def test_damage_breakpoints():
    values = damage_fraction(np.array([0.0, 0.2, 0.4, 0.6, 0.8]))
    expected = np.array([0.0, 1 / 15000, 1 / 10000, 1 / 8000, 1 / 6000])
    np.testing.assert_allclose(values, expected, rtol=1e-12, atol=1e-14)


def test_equal_efc_cases_match_rainflow_and_surrogate():
    rows = equal_efc_validation_cases()
    expected_damage = [2.25e-4, 3.333333333333333e-4, 2.666666666666667e-4]
    for row, expected in zip(rows, expected_damage):
        assert abs(row["efc"] - 1.0) < 1e-12
        assert abs(row["rainflow_damage"] - expected) < 1e-12
        assert abs(row["surrogate_damage"] - expected) < 1e-12
        assert row["relative_deviation_pct"] < 1e-10


def test_efc_uses_rated_energy_basis():
    energy = np.array([1.0, 0.2, 1.4, 0.2, 1.0])
    assert np.isclose(equivalent_full_cycles(energy), 1.0)


def test_turning_point_surrogate_for_flat_segments():
    soc = np.array([0.5, 0.5, 0.1, 0.1, 0.7, 0.7, 0.5])
    assert np.isclose(peak_valley_surrogate(soc), rainflow_damage(soc))
