import numpy as np
from bess_dro.wasserstein import (
    finite_support_worst_case_expectation, wasserstein_ground_distance,
)


def test_ground_metric():
    a = np.array([[0.0, 0.0], [0.2, -0.1]])
    b = np.array([[0.1, 0.0], [0.0, 0.1]])
    expected = (0.1 + 0.0 + 0.2 + 0.2) / 4
    assert np.isclose(wasserstein_ground_distance(a, b), expected)


def test_finite_support_wasserstein_radius_zero():
    nominal = np.array([[[0.0, 0.0]], [[1.0, 1.0]]])
    candidates = nominal.copy()
    value, transport = finite_support_worst_case_expectation(
        candidates, nominal, np.array([1.0, 0.0]), np.array([1.0, 3.0]), radius=0.0
    )
    assert np.isclose(value, 1.0)
    assert np.isclose(transport.sum(), 1.0)


def test_finite_support_wasserstein_large_radius():
    nominal = np.array([[[0.0, 0.0]], [[1.0, 1.0]]])
    candidates = nominal.copy()
    value, _ = finite_support_worst_case_expectation(
        candidates, nominal, np.array([1.0, 0.0]), np.array([1.0, 3.0]), radius=1.0
    )
    assert np.isclose(value, 3.0)
