from bess_dro.network import backward_forward_sweep, ieee33_loads


def test_ieee33_base_load_and_power_flow():
    p, q = ieee33_loads()
    assert abs(p.sum() - 3.715) < 1e-12
    assert abs(q.sum() - 2.30) < 1e-12
    result = backward_forward_sweep()
    assert result.converged
    assert result.voltage_pu.shape == (33,)
    assert result.branch_current_pu.shape == (32,)
    assert 0.85 < result.minimum_voltage_pu < 1.0
    assert result.losses_mw > 0
