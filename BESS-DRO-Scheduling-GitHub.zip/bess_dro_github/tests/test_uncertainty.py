import numpy as np
from bess_dro.uncertainty import (
    fit_gaussian_copula, reduce_daily_trajectories, sample_gaussian_copula,
)


def test_gaussian_copula_parameter_estimation():
    rng = np.random.default_rng(17)
    rho = -0.51
    z = rng.multivariate_normal([0, 0], [[1, rho], [rho, 1]], size=12000)
    fit = fit_gaussian_copula(z[:, 0], z[:, 1])
    assert abs(fit.rho - rho) < 0.04
    assert fit.kendall_tau_fitted < 0


def test_copula_sampling_preserves_negative_dependence():
    rng = np.random.default_rng(23)
    pv = rng.normal(size=3000)
    load = rng.normal(size=3000)
    samples = sample_gaussian_copula(5000, pv, load, rho=-0.51, rng=rng)
    assert np.corrcoef(samples.T)[0, 1] < -0.35


def test_kmeans_reduction_probabilities():
    rng = np.random.default_rng(9)
    trajectories = rng.normal(size=(40, 12, 2))
    reps, probs, labels = reduce_daily_trajectories(trajectories, n_clusters=6, random_state=2)
    assert reps.shape == (6, 12, 2)
    assert labels.shape == (40,)
    assert np.isclose(probs.sum(), 1.0)
    assert np.all(probs > 0)
