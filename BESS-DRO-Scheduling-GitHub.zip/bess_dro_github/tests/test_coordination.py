import numpy as np
from bess_dro.coordination import interpolate_hourly_energy, tracking_slack


def test_hourly_to_quarter_hour_interpolation():
    hourly = np.linspace(1.0, 1.0, 25)
    intraday = interpolate_hourly_energy(hourly)
    assert intraday.shape == (97,)
    np.testing.assert_allclose(intraday, 1.0)


def test_tracking_slack_deadband():
    ref = np.array([1.0, 1.0, 1.0])
    actual = np.array([1.02, 1.10, 0.90])
    slack = tracking_slack(actual, ref, tolerance_mwh=0.05)
    np.testing.assert_allclose(slack, [0.0, 0.05, 0.05])
