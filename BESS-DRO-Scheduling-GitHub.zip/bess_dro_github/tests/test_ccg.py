import numpy as np
from bess_dro.ccg import (
    AdversarialCandidate, CCGConfig, MasterSolution, run_adaptive_multicut_ccg,
)


def test_iccg_controller_stopping_and_bound_update():
    def master_solver(scenarios, cuts, tolerance):
        return MasterSolution(
            first_stage={"dispatch": 1.0},
            lower_bound=9.999,
            day_ahead_cost=5.0,
            degradation_cost=1.0,
            wasserstein_lambda=0.0,
            theta=np.array([4.0]),
        )

    def adversarial_solver(solution, center_index, center_scenario):
        return [AdversarialCandidate(
            center_index=center_index,
            scenario=np.asarray(center_scenario),
            recourse_cost=4.0,
            wasserstein_distance=0.0,
        )]

    result = run_adaptive_multicut_ccg(
        nominal_probabilities=np.array([1.0]),
        wasserstein_radius=0.05,
        master_solver=master_solver,
        adversarial_solver=adversarial_solver,
        initial_scenarios=[np.zeros((2, 2))],
        config=CCGConfig(),
    )
    assert result.iterations == 1
    assert result.relative_gap < 0.001
    assert np.isclose(result.upper_bound, 10.0)
