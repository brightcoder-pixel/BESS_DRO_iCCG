# Computational Reproducibility

## Reference computational environment

The manuscript reports MATLAB R2022a, IBM ILOG CPLEX 12.10, an Intel Core i7-12700 processor, and 32 GB RAM for the standard C&CG/iCCG runtime comparison.

## Python companion environment

The companion routines use Python 3.10+, NumPy, SciPy, pandas, scikit-learn, and Matplotlib. A fixed random seed (`2026`) is used by the demonstration workflow.

## Commands

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
pytest -q
python scripts/run_demo.py
python scripts/reproduce_figures.py
```

## Generated outputs

`run_demo.py` writes sampled error trajectories, representative scenarios, scenario probabilities, Copula fitting statistics, equal-EFC degradation results, and reference figures to `outputs/demo/`.

`reproduce_figures.py` reads only the reference CSV tables and writes the four manuscript result figures to `outputs/reference_figures/`.
