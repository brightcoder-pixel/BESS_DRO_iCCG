# Test Report

The repository test suite was executed with `pytest -q`.

```text
14 passed
```

The test suite covers:

- DoD damage interpolation at all five calibration breakpoints;
- the three equal-EFC cycling patterns and Rainflow/peak-valley damage agreement;
- EFC calculation on the rated-energy basis;
- 24-hour to 15-minute energy interpolation;
- stored-energy tracking deadband;
- Gaussian Copula parameter estimation and correlated sampling;
- K-means scenario reduction and scenario probability normalization;
- the Wasserstein ground metric and finite-support transport LP;
- adaptive iCCG bound updates and stopping logic;
- IEEE 33-bus base-load totals and radial power-flow convergence.
