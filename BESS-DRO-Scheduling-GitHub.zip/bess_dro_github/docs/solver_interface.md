# iCCG Solver-Oracle Interface

The iCCG controller in `bess_dro/ccg.py` is independent of the mathematical programming API. The optimization models are connected through two callable interfaces.

## Master-problem oracle

```python
def master_solver(scenarios, cuts, gap_tolerance) -> MasterSolution:
    ...
```

The returned `MasterSolution` contains:

- `first_stage`: the day-ahead decision vector or a solver-specific decision object;
- `lower_bound`: objective value of the restricted master problem;
- `day_ahead_cost`: day-ahead operating cost;
- `degradation_cost`: MILP peak-valley degradation cost;
- `wasserstein_lambda`: nonnegative Wasserstein dual variable;
- `theta`: one recourse-cost approximation per nominal representative scenario.

## Adversarial-subproblem oracle

```python
def adversarial_solver(master_solution, center_index, center_scenario):
    ...
    return [AdversarialCandidate(...)]
```

Each `AdversarialCandidate` contains the candidate uncertainty trajectory, its recourse cost, the ground-metric distance to the nominal center, and the corresponding center index.

## Controller operations

At each iteration, the controller:

1. solves the restricted master problem and updates the lower bound;
2. evaluates the adversarial candidates for every nominal center;
3. calculates the upper-bound candidate using the Wasserstein dual expression;
4. updates the best upper bound and relative gap;
5. ranks violated scenario-specific cuts and adds up to three cuts;
6. contracts the master gap tolerance by the configured factor;
7. stops at a relative gap of 0.10% or the maximum iteration count.

The default numerical settings are stored in `CCGConfig` and match the manuscript settings.

## Minimal usage pattern

```python
from bess_dro.ccg import (
    AdversarialCandidate,
    CCGConfig,
    MasterSolution,
    run_adaptive_multicut_ccg,
)

result = run_adaptive_multicut_ccg(
    nominal_probabilities=probabilities,
    wasserstein_radius=0.05,
    master_solver=master_solver,
    adversarial_solver=adversarial_solver,
    initial_scenarios=representative_scenarios,
    config=CCGConfig(),
)
```

The callback implementations can use the optimization package selected for the study environment. The manuscript's computational environment is MATLAB R2022a with IBM ILOG CPLEX 12.10.
