# Model Equation and Source-Code Map

| Manuscript formulation | Implementation |
|---|---|
| Normalized PV/load forecast errors, Eqs. (1)–(3) | `uncertainty.py`: `fit_gaussian_copula`, `sample_gaussian_copula`, `reconstruct_actual_trajectories` |
| Gaussian Copula dependence parameter | `config.py`: `StudyConfig.copula_rho`; `uncertainty.py` |
| K-means reduction of daily trajectories | `uncertainty.py`: `reduce_daily_trajectories` |
| First-order Wasserstein metric, Eq. (7) | `wasserstein.py`: `wasserstein_ground_distance` |
| Finite-support worst-case distribution evaluation | `wasserstein.py`: `finite_support_worst_case_expectation` |
| BESS energy and SOC constraints, Eqs. (9)–(12) | `config.py`; `coordination.py` |
| SOC peak/valley turning points and DoD damage, Eqs. (13)–(19) | `degradation.py`: `turning_points`, `damage_fraction`, `peak_valley_surrogate` |
| Ex-post Rainflow damage, Eq. (20) | `degradation.py`: `rainflow_count`, `rainflow_damage` |
| Equivalent full cycles, Eq. (21) | `degradation.py`: `equivalent_full_cycles` |
| Radial distribution feeder AC evaluation | `network.py`: `backward_forward_sweep` |
| Intraday energy tracking, Eqs. (32)–(36) | `coordination.py`: `interpolate_hourly_energy`, `tracking_slack`, `tracking_penalty_usd` |
| Master/adversarial iteration and bound management, Eqs. (39)–(48) | `ccg.py`: `run_adaptive_multicut_ccg` |
| Reported numerical case-study tables | `data/reference/*.csv` |
| Reference result plots | `plotting.py`; `scripts/reproduce_figures.py` |

## Battery degradation interpolation

The cycle damage breakpoints are

| DoD | Cycle life | Damage fraction |
|---:|---:|---:|
| 0% | — | 0 |
| 20% | 15,000 | 1/15,000 |
| 40% | 10,000 | 1/10,000 |
| 60% | 8,000 | 1/8,000 |
| 80% | 6,000 | 1/6,000 |

Linear interpolation is applied between adjacent DoD breakpoints. The net battery replacement cost is USD 180,000.

For the peak-valley surrogate, each adjacent turning-point excursion contributes a half-cycle damage term. The ex-post Rainflow calculation uses full-cycle and residual half-cycle weights. The two calculations are kept as separate functions.

## iCCG controller

`run_adaptive_multicut_ccg` receives two solver callbacks:

- `master_solver(scenarios, cuts, gap_tolerance) -> MasterSolution`
- `adversarial_solver(master_solution, center_index, center_scenario) -> list[AdversarialCandidate]`

The controller performs lower-bound and upper-bound updates, computes the relative gap, shrinks the master tolerance, ranks violated scenario cuts, and adds up to three cuts per iteration. The final gap tolerance is 0.10%, and the iteration limit is 50.
