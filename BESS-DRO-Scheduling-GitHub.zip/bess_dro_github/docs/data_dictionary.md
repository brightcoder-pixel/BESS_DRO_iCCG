# Data Dictionary

## Reference tables

All files in `data/reference/` are comma-separated UTF-8 tables. Their columns and units are encoded in their names.

| File | Contents |
|---|---|
| `main_benchmark.csv` | DET, SP, RO, and proposed DRO benchmark results; mean cost, 95% interval, minimum voltage, voltage-violation probability |
| `wasserstein_sensitivity.csv` | Cost, minimum voltage, average cycle DoD, and degradation cost versus Wasserstein radius |
| `degradation_ablation.csv` | Aging-penalty ablation: realized cost, Rainflow aging cost, EFC, maximum DoD, throughput, and aging cost per EFC |
| `weather_robustness.csv` | Clear, cloudy, and variable-cloud operating conditions for the four scheduling methods |
| `copula_fit.csv` | Gaussian, Frank, and t-Copula fitting diagnostics |
| `dependence_comparison.csv` | Independent marginal sampling versus Copula-Wasserstein scenario modeling |
| `timescale_comparison.csv` | Day-ahead-only, two-stage without interpolation, and proposed interpolated two-stage scheduling |
| `ccg_runtime.csv` | Standard C&CG and proposed iCCG computational performance |
| `rainflow_validation.csv` | Three equal-EFC SOC cycling patterns and damage comparison |

## Forecast input arrays

The uncertainty functions accept paired normalized forecast-error samples:

- `pv_errors`: normalized PV forecast errors;
- `load_errors`: normalized load forecast errors.

For daily scenario generation, the output shape is `(n_trajectories, 96, 2)`. The last axis is ordered as `[PV_error, load_error]`.

## Physical trajectory reconstruction

`reconstruct_actual_trajectories` uses:

\[
P^{act}_{PV,t}=P^{DA}_{PV,t}+\epsilon_{PV,t}P^{rated}_{PV}
\]

\[
P^{act}_{L,t}=P^{DA}_{L,t}+\epsilon_{L,t}P^{base}_{L}
\]

PV output is clipped to the physical interval from zero to rated capacity, and load is constrained to be nonnegative.

## Stored-energy trajectory

The day-ahead input to `interpolate_hourly_energy` contains 25 boundary values, from hour 0 through hour 24. The output contains 97 points at 15-minute resolution.
