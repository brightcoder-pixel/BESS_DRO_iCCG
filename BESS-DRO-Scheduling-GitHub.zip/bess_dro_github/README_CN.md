# 光伏高渗透率配电网中考虑相关性与退化特性的储能调度代码

本项目为论文 **Correlation-and Degradation-Aware Two-Stage Distributionally Robust Scheduling of Battery Energy Storage in PV-Rich Distribution Networks** 配套的计算代码与技术文件。

## 1. 主要功能

- 基于 Gaussian Copula 的光伏—负荷预测误差相关性建模与联合采样；
- 基于 K-means 的完整日轨迹场景削减及场景概率计算；
- 基于等权 L1 距离的 Wasserstein 距离与有限支持集最坏分布期望计算；
- 基于 DoD 分段循环寿命数据的分段线性电池损伤函数；
- Rainflow 循环计数、峰谷循环损伤替代模型及 EFC 计算；
- 日前 24 h 储能轨迹向日内 96 个 15 min 时段插值，以及储能轨迹跟踪松弛量计算；
- 自适应多割 C&CG/iCCG 算法控制器，包括上下界更新、间隙收缩、割平面筛选和终止判据；
- Baran-Wu IEEE 33 节点径向配电网前推回代潮流计算；
- 论文数值结果表格整理及绘图。

## 2. 环境配置

Python 3.10 或更高版本。安装依赖：

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
```

## 3. 运行示例

在项目根目录执行：

```bash
python scripts/run_demo.py
```

程序采用固定随机种子生成演示误差样本，完成 Gaussian Copula 参数拟合、500 组 96 时段误差轨迹生成、20 个代表性场景削减、三组等 EFC 电池退化算例计算，并根据论文结果表生成图件。结果保存在 `outputs/demo/`。

## 4. 生成论文结果图

```bash
python scripts/reproduce_figures.py
```

图件保存在 `outputs/reference_figures/`，包括：

1. 不同调度方法的经济性与电压越限概率对比；
2. Wasserstein 半径敏感性分析；
3. 不同电池退化成本模型的消融对比；
4. 标准 C&CG 与 iCCG 计算效率对比。

## 5. 运行测试

```bash
pytest -q
```

## 6. 主要参数

所有主要参数集中保存在 `config/study_parameters.json` 和 `bess_dro/config.py` 中，包括：

- 配电网：12.66 kV，基准负荷 3.715 MW / 2.30 Mvar；
- 光伏接入节点：10、17、24、30，对应容量 0.55、0.65、0.60、0.70 MW；
- 分布式电源：节点 6、25，各 0.5 MW；
- 储能接入节点：17，额定容量 2.0 MWh，充放电功率 0.4 MW；
- 充放电效率：0.95，储能量范围：0.2–1.8 MWh；
- 日前与日内时间尺度：1 h / 15 min；
- Gaussian Copula 参数：\(\rho=-0.51\)；
- Wasserstein 半径：0.05；
- 代表性场景数：20，样本外轨迹数：500；
- iCCG 初始间隙：5%，最终间隙：0.10%，最大迭代次数：50，每轮最多添加 3 个割。

## 7. 代码模块

| 文件 | 功能 |
|---|---|
| `bess_dro/uncertainty.py` | Gaussian Copula、联合误差采样、K-means 场景削减 |
| `bess_dro/wasserstein.py` | Wasserstein 地面距离与有限支持集运输优化 |
| `bess_dro/degradation.py` | DoD 损伤函数、峰谷替代模型、Rainflow、EFC |
| `bess_dro/coordination.py` | 日前—日内储能轨迹插值与跟踪惩罚 |
| `bess_dro/ccg.py` | 自适应多割 iCCG 算法控制流程 |
| `bess_dro/network.py` | IEEE 33 节点径向配电网前推回代潮流 |
| `bess_dro/plotting.py` | 论文数值结果图件生成 |
| `data/reference/` | 论文数值结果表格 |

论文数值优化环境为 MATLAB R2022a 与 IBM ILOG CPLEX 12.10。Python 版本的 `ccg.py` 将主问题和对抗子问题作为求解器回调接口，独立实现 iCCG 的上下界管理、自适应间隙控制和多割筛选逻辑。

IEEE 33 节点径向网络基础参数采用 MATPOWER 的 `case33bw`，论文中的光伏、分布式电源及储能接入位置和容量在本项目参数文件中单独配置。

## 8. 论文引用

论文题目、作者信息及引用元数据见 `CITATION.cff`。
